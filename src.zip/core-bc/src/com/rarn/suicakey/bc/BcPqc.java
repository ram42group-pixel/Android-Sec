package com.rarn.suicakey.bc;

import com.rarn.suicakey.core.Bytes;
import com.rarn.suicakey.core.Pqc;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import org.bouncycastle.crypto.SecretWithEncapsulation;
import org.bouncycastle.jcajce.spec.MLDSAParameterSpec;
import org.bouncycastle.jcajce.spec.MLKEMParameterSpec;
import org.bouncycastle.pqc.crypto.mlkem.MLKEMExtractor;
import org.bouncycastle.pqc.crypto.mlkem.MLKEMGenerator;
import org.bouncycastle.pqc.crypto.mlkem.MLKEMPrivateKeyParameters;
import org.bouncycastle.pqc.crypto.mlkem.MLKEMPublicKeyParameters;
import org.bouncycastle.pqc.crypto.util.PrivateKeyFactory;
import org.bouncycastle.pqc.crypto.util.PublicKeyFactory;

/** BouncyCastle（Android用）実装。プロバイダ "BC" を明示指定。 */
public final class BcPqc extends Pqc {
    public BcPqc() { super("BC"); }

    @Override
    public KeyPair genMlKem768() throws GeneralSecurityException {
        KeyPairGenerator g = kpg("ML-KEM");
        g.initialize(MLKEMParameterSpec.ml_kem_768, Bytes.RNG);
        return g.generateKeyPair();
    }

    @Override
    public KeyPair genMlDsa65() throws GeneralSecurityException {
        KeyPairGenerator g = kpg("ML-DSA");
        g.initialize(MLDSAParameterSpec.ml_dsa_65, Bytes.RNG);
        return g.generateKeyPair();
    }

    @Override
    public byte[][] encaps(PublicKey pk) throws GeneralSecurityException {
        try {
            MLKEMPublicKeyParameters p = (MLKEMPublicKeyParameters) PublicKeyFactory.createKey(pk.getEncoded());
            SecretWithEncapsulation s = new MLKEMGenerator(Bytes.RNG).generateEncapsulated(p);
            return new byte[][]{s.getEncapsulation(), s.getSecret()};
        } catch (java.io.IOException e) {
            throw new GeneralSecurityException(e);
        }
    }

    @Override
    public byte[] decaps(PrivateKey sk, byte[] ct) throws GeneralSecurityException {
        try {
            MLKEMPrivateKeyParameters p = (MLKEMPrivateKeyParameters) PrivateKeyFactory.createKey(sk.getEncoded());
            return new MLKEMExtractor(p).extractSecret(ct);
        } catch (java.io.IOException e) {
            throw new GeneralSecurityException(e);
        }
    }
}
