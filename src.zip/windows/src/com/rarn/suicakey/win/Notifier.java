package com.rarn.suicakey.win;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 緊急通知の送信。
 *  Telegram : https://api.telegram.org/bot<TOKEN>/sendMessage?chat_id=<ID>（文面＋地図ピン）
 *  Discord / Slack : Webhook URL
 *  その他（ntfy等）: テキストをPOST
 */
final class Notifier {
    private Notifier() {}

    static final Pattern TOKEN = Pattern.compile("\\d{5,}:[A-Za-z0-9_-]{30,}");
    private static final Pattern TG_PATH = Pattern.compile("/bot(\\d{5,}:[A-Za-z0-9_-]{30,})/sendMessage");

    private static final HttpClient HC = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    static String telegramUrl(String token, String chatId) {
        return "https://api.telegram.org/bot" + token + "/sendMessage?chat_id=" + URLEncoder.encode(chatId, StandardCharsets.UTF_8);
    }

    static boolean isTelegram(String url) {
        try { return "api.telegram.org".equalsIgnoreCase(URI.create(url.trim()).getHost()); } catch (Exception e) { return false; }
    }

    /** ボットに最後にメッセージを送ったチャットのIDを取得（/start を送ってから呼ぶ） */
    static String telegramChatId(String token) {
        try {
            HttpRequest rq = HttpRequest.newBuilder(URI.create("https://api.telegram.org/bot" + token + "/getUpdates"))
                    .timeout(Duration.ofSeconds(15)).GET().build();
            HttpResponse<String> r = HC.send(rq, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() != 200) return null;
            Matcher m = Pattern.compile("\"chat\"\\s*:\\s*\\{\\s*\"id\"\\s*:\\s*(-?\\d+)").matcher(r.body());
            String id = null;
            while (m.find()) id = m.group(1);
            return id;
        } catch (Exception e) {
            return null;
        }
    }

    static boolean send(String url, String text) { return send(url, text, null, null); }

    /** @param lat,lon 位置（Telegramでは地図ピンも送る。不明なら null） */
    static boolean send(String url, String text, String lat, String lon) {
        if (url == null || url.isBlank()) return false;
        try {
            URI u = URI.create(url.trim());
            if (!"https".equalsIgnoreCase(u.getScheme())) return false;
            String host = u.getHost() == null ? "" : u.getHost().toLowerCase();

            if (host.equals("api.telegram.org")) {
                Matcher pm = TG_PATH.matcher(u.getRawPath());
                String chat = query(u.getRawQuery(), "chat_id");
                if (!pm.matches() || chat == null) return false;
                String base = "https://api.telegram.org/bot" + pm.group(1) + "/";
                String cj = chat.matches("-?\\d+") ? chat : json(chat);
                boolean ok = post(base + "sendMessage", "application/json",
                        "{\"chat_id\":" + cj + ",\"text\":" + json(text) + ",\"disable_web_page_preview\":true}");
                if (ok && lat != null && lon != null && lat.matches("-?\\d+(\\.\\d+)?") && lon.matches("-?\\d+(\\.\\d+)?")) {
                    post(base + "sendLocation", "application/json",
                            "{\"chat_id\":" + cj + ",\"latitude\":" + lat + ",\"longitude\":" + lon + "}");
                }
                return ok;
            }
            if (host.endsWith("discord.com") || host.endsWith("discordapp.com"))
                return post(url, "application/json", "{\"content\":" + json(text) + "}");
            if (host.equals("hooks.slack.com"))
                return post(url, "application/json", "{\"text\":" + json(text) + "}");
            return post(url, "text/plain; charset=utf-8", text);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean post(String url, String type, String body) throws InterruptedException {
        HttpRequest rq = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15))
                .header("Content-Type", type).POST(HttpRequest.BodyPublishers.ofString(body)).build();
        for (int i = 0; i < 3; i++) {
            try {
                int code = HC.send(rq, HttpResponse.BodyHandlers.discarding()).statusCode();
                if (code >= 200 && code < 300) return true;
                if (code >= 400 && code < 500 && code != 429) return false; // 設定ミスは再試行しない
            } catch (Exception ignored) { }
            Thread.sleep(3000L * (i + 1));
        }
        return false;
    }

    private static String query(String q, String key) {
        if (q == null) return null;
        for (String kv : q.split("&")) {
            int i = kv.indexOf('=');
            if (i > 0 && kv.substring(0, i).equals(key))
                return java.net.URLDecoder.decode(kv.substring(i + 1), StandardCharsets.UTF_8);
        }
        return null;
    }

    static String json(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': break;
                default:
                    if (ch < 0x20) b.append(String.format("\\u%04x", (int) ch)); else b.append(ch);
            }
        }
        return b.append('"').toString();
    }
}
