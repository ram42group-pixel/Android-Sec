package com.rarn.suicakey.win;

import com.rarn.suicakey.core.Bytes;
import com.rarn.suicakey.core.IO;
import com.rarn.suicakey.core.Msg;
import com.rarn.suicakey.core.PairCtx;
import com.rarn.suicakey.core.PcSide;
import com.rarn.suicakey.core.Pqc;
import com.rarn.suicakey.core.Proto;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** LAN待受。検証に失敗した接続には一切応答せず切断する（無反応）。 */
public final class Server {
    public interface Ui {
        void copy(String password);
        void info(String msg);
        void refresh();
    }

    private static final class Pend {
        final PcSide.Session s; final byte[] id, ch; final long exp; final boolean unlock;
        Pend(PcSide.Session s, byte[] id, byte[] ch, long exp, boolean unlock) {
            this.s = s; this.id = id; this.ch = ch; this.exp = exp; this.unlock = unlock;
        }
    }

    static final long DURESS_LOCK_SEC = 24 * 3600;
    /** 登録モード：この期限内の次の認証で、Suica×PINに M を包んで保存 */
    private volatile byte[] registerM;
    private volatile long registerUntil;

    public synchronized void armRegister(byte[] m) {
        Bytes.wipe(registerM);
        registerM = m;
        registerUntil = Proto.now() + 300;
    }

    /** 練習モード（この時刻まで、緊急PINでも通知・停止しない） */
    private volatile long practiceUntil;

    final Pqc c;
    final Store st;
    volatile Ui ui;
    volatile PairCtx pairing;
    private final Map<String, PcSide.Session> sessions = new ConcurrentHashMap<>();
    private final Map<String, Pend> pend = new ConcurrentHashMap<>();
    private ServerSocket ss;
    /** 総当たり対策：端末ごとの応答検証は5秒に1回まで（超過分は無反応） */
    private final Map<String, Long> lastResp = new ConcurrentHashMap<>();

    public Server(Pqc c, Store st) { this.c = c; this.st = st; }

    public void start() throws java.io.IOException {
        ss = new ServerSocket();
        ss.bind(new InetSocketAddress(Proto.PORT), 16);
        Thread t = new Thread(() -> {
            while (!ss.isClosed()) {
                try {
                    Socket s = ss.accept();
                    Thread h = new Thread(() -> handle(s), "conn");
                    h.setDaemon(true);
                    h.start();
                } catch (Exception ignored) { }
            }
        }, "accept");
        t.setDaemon(true);
        t.start();
    }

    public List<String> connectedNames() {
        List<String> l = new ArrayList<>();
        for (PcSide.Session s : sessions.values()) l.add(s.phone.name);
        return l;
    }

    private void handle(Socket s) {
        String key = null;
        PcSide.Session ses = null;
        try (IO io = new IO(s)) {
            s.setSoTimeout(20_000);
            s.setTcpNoDelay(true);
            Msg m = Msg.decode(io.read());
            if (m.type == Proto.PAIR1) {
                PairCtx p = pairing;
                if (p != null && p.active()) {
                    io.setTimeout(200_000);
                    PcSide.pair(c, io, m, p, st);
                }
                return;
            }
            ses = PcSide.session(c, io, m, st);
            if (ses == null) return;
            key = Bytes.hex(ses.phone.id);
            PcSide.Session old = sessions.put(key, ses);
            if (old != null) old.ch.close();
            refresh();
            io.setTimeout(200_000);
            int bad = 0;
            while (true) {
                Msg r = ses.ch.recv();
                if (r.type == Proto.PING) {
                    ses.ch.send(new Msg(Proto.PONG));
                } else if (r.type == Proto.WANT) {
                    sendReq(ses, "スマホからの送信", false);
                } else if (r.type == Proto.RESP) {
                    if (!onResp(ses, r) && ++bad >= 3) return;
                } else {
                    return;
                }
            }
        } catch (Exception ignored) {
            // 無反応
        } finally {
            if (key != null) sessions.remove(key, ses);
            refresh();
        }
    }

    private boolean onResp(PcSide.Session s, Msg r) throws Exception {
        if (r.n() < 1) return false;
        String who = Bytes.hex(s.phone.id);
        long t = System.nanoTime();
        Long prev = lastResp.put(who, t);
        if (prev != null && t - prev < 5_000_000_000L) return false;
        Pend p = pend.remove(Bytes.hex(r.get(0)));
        if (p == null || p.s != s) return false;
        long now = Proto.now();
        byte[] regM;
        synchronized (this) { regM = (!p.unlock && now < registerUntil) ? registerM : null; }
        PcSide.Result res = PcSide.checkResp(c, st, s, r, p.id, p.ch, p.exp, regM);
        if (res.code == PcSide.REGISTERED) {
            synchronized (this) { Bytes.wipe(registerM); registerM = null; registerUntil = 0; }
            ui.copy(res.password);
            ui.info("カードとPINを登録しました（パスワードをコピー）");
            s.ch.send(new Msg(Proto.DONE, p.id));
            return true;
        }
        if (res.lockedNow) notifyText("【SuicaKey 警告】\nPINの連続失敗（" + PcSide.MAX_REMOTE_FAILS + "回）により端末「"
                + s.phone.name + "」をロックしました。\n時刻: " + java.time.LocalDateTime.now().withNano(0));
        if (res.code == PcSide.UNREGISTERED) {
            ui.info("エラーです");
            return false;
        }
        if (res.code == PcSide.OK) {
            if (p.unlock) {
                // 本物のSuica＋本物のPINでのみ緊急停止を解除できる
                st.setDuressUntil(0);
                st.log("緊急停止を解除: " + s.phone.name);
                st.save();
                ui.info("緊急停止を解除しました");
                s.ch.send(new Msg(Proto.DONE, p.id));
                return true;
            }
            if (now < st.duressUntil()) return false; // 停止中は本物の認証にも無反応
            ui.copy(res.password);
            s.ch.send(new Msg(Proto.DONE, p.id));
            return true;
        }
        if (res.code == PcSide.DURESS) {
            if (p.unlock) return false;
            // 見た目は通常と完全に同じ：偽のパスワードをコピーして完了を返す
            ui.copy(res.password);
            s.ch.send(new Msg(Proto.DONE, p.id));
            if (now < practiceUntil) {
                practiceUntil = 0;
                st.log("緊急PINの練習（通知・停止なし）: " + s.phone.name);
                st.save();
                return true;
            }
            st.setDuressUntil(now + DURESS_LOCK_SEC);
            st.log("緊急PINを検知 → 24時間停止・通知: " + s.phone.name + (res.location.isEmpty() ? "" : " 位置=" + res.location));
            st.save();
            notifyDuress(s.phone.name, res.location);
            return true;
        }
        return false; // 無反応
    }

    private void notifyDuress(String phone, String loc) {
        String url = st.webhook();
        if (url.isEmpty()) return;
        StringBuilder m = new StringBuilder("【SuicaKey 緊急通知】\n緊急PINが使用されました。\n");
        m.append("時刻: ").append(java.time.LocalDateTime.now().withNano(0)).append('\n');
        m.append("端末: ").append(phone).append('\n');
        String lat = null, lon = null;
        if (!loc.isEmpty()) {
            String[] a = loc.split(",");
            if (a.length >= 2) { lat = a[0]; lon = a[1]; }
            if (a.length >= 2) m.append("位置: https://maps.google.com/?q=").append(a[0]).append(',').append(a[1]);
            if (a.length >= 3) m.append("（誤差約").append(a[2]).append("m）");
        } else {
            m.append("位置: 取得できませんでした");
        }
        String text = m.toString();
        String fLat = lat, fLon = lon;
        Thread t = new Thread(() -> {
            boolean ok = Notifier.send(url, text, fLat, fLon);
            st.log(ok ? "緊急通知を送信" : "緊急通知の送信に失敗");
            st.save();
        });
        t.setDaemon(false);
        t.start();
    }

    private void notifyText(String text) {
        String url = st.webhook();
        if (url.isEmpty()) return;
        Thread t = new Thread(() -> { boolean ok = Notifier.send(url, text); st.log(ok ? "警告通知を送信" : "警告通知の送信に失敗"); st.save(); });
        t.setDaemon(false);
        t.start();
    }

    /** 次の1回だけ、緊急PINを使っても通知・停止しない（偽パスワードの確認用） */
    public void armPractice() { practiceUntil = Proto.now() + 300; }

    /** 本物のSuica＋PINで緊急停止を解除 */
    public void requestUnlock() {
        if (sessions.isEmpty()) { ui.info("エラーです"); return; }
        for (PcSide.Session s : sessions.values()) sendReq(s, "緊急停止の解除（本物のPINで）", true);
    }

    /** 通知先のテスト送信 */
    public void testNotify() {
        String url = st.webhook();
        if (url.isEmpty()) { ui.info("エラーです"); return; }
        new Thread(() -> ui.info(Notifier.send(url, "【SuicaKey】通知テストです") ? "テスト通知を送信しました" : "エラーです")).start();
    }

    /** Windows側からの認証依頼 → スマホに通知 */
    public void requestAuth(String label) {
        if (sessions.isEmpty()) { ui.info("エラーです"); return; }
        for (PcSide.Session s : sessions.values()) sendReq(s, label, false);
    }

    private void sendReq(PcSide.Session s, String label, boolean unlock) {
        long now = Proto.now();
        pend.values().removeIf(p -> p.exp < now);
        byte[] id = Bytes.rnd(16), ch = Bytes.rnd(32);
        long exp = now + 90;
        pend.put(Bytes.hex(id), new Pend(s, id, ch, exp, unlock));
        try {
            s.ch.send(new Msg(Proto.REQ, id, ch, Bytes.utf8(label), Bytes.u64(exp)));
        } catch (Exception ignored) { }
    }

    private void refresh() { Ui u = ui; if (u != null) u.refresh(); }
}
