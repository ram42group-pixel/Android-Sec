package com.rarn.suicakey.win;

import java.awt.AWTException;
import java.awt.CheckboxMenuItem;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.RenderingHints;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.image.BufferedImage;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.Timer;

/** タスクトレイ常駐UI */
final class Tray implements Server.Ui {
    private static final String RUN_KEY = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    private final Server srv;
    private final Store st;
    private TrayIcon icon;
    private final MenuItem conn = new MenuItem("接続: なし");
    private final Admin admin;

    Tray(Server srv, Store st, Admin admin) { this.srv = srv; this.st = st; this.admin = admin; }

    /** メニュー項目（guarded=true なら管理者パスワードで保護） */
    private void item(Menu menu, String label, boolean guarded, Runnable r) {
        MenuItem it = new MenuItem(label);
        it.addActionListener(e -> EventQueue.invokeLater(() -> { if (!guarded || admin.require("「" + label + "」")) r.run(); }));
        menu.add(it);
    }

    void init() throws AWTException {
        PopupMenu m = new PopupMenu();
        conn.setEnabled(false);
        m.add(conn);
        m.addSeparator();
        MenuItem req = new MenuItem("スマホに認証を依頼");
        req.addActionListener(e -> srv.requestAuth("PCからの認証依頼"));
        m.add(req);
        m.addSeparator();
        MenuItem pair = new MenuItem("ペアリング…");
        pair.addActionListener(e -> EventQueue.invokeLater(() -> {
            if (!admin.require("ペアリング")) return;
            try { new PairWindow(srv); } catch (Exception ex) { info("エラーです"); }
        }));
        m.add(pair);
        CheckboxMenuItem auto = new CheckboxMenuItem("ログオン時に自動起動", autostartEnabled());
        auto.addItemListener(e -> EventQueue.invokeLater(() -> {
            boolean want = auto.getState();
            if (!want && !admin.require("自動起動の解除")) { auto.setState(true); return; }
            setAutostart(want);
        }));
        m.add(auto);

        Menu adv = new Menu("管理");
        item(adv, "初期設定（管理者パスワード・キーファイル）…", false, admin::setup);
        item(adv, "カード/PINを登録（キーファイル使用）…", false, admin::register);
        item(adv, "パスワードを緊急表示（キーファイル使用）…", false, () -> admin.showPassword(this));
        adv.addSeparator();
        item(adv, "緊急通知をTelegramに設定…", true, this::setupTelegram);
        item(adv, "緊急通知の送信先（URL直接入力）…", true, this::editWebhook);
        MenuItem test = new MenuItem("緊急通知のテスト送信");
        test.addActionListener(e -> srv.testNotify());
        adv.add(test);
        item(adv, "偽パスワードを確認（緊急PINの練習）", true, () -> {
            if (confirm("この後5分以内の1回だけ、緊急PINを使っても通知・停止をしません。\n"
                    + "スマホで「PCへ送る」→ Suica → 緊急PIN の順に操作すると、偽のパスワードがコピーされます。\n"
                    + "それを囮用の保管場所（KeePassの別DBなど）のパスワードに設定してください。")) {
                srv.armPractice();
                info("練習モード：5分間有効");
            }
        });
        MenuItem unlock = new MenuItem("緊急停止を解除（スマホ・本物のPIN）");
        unlock.addActionListener(e -> srv.requestUnlock());
        adv.add(unlock);
        item(adv, "緊急停止を解除（管理者パスワード）", false, admin::unlockDuress);
        item(adv, "端末ロックを解除（PIN連続失敗）", false, admin::unlockPhones);
        adv.addSeparator();
        item(adv, "セキュリティ履歴", true, this::showLog);
        item(adv, "ペアリング解除", true, () -> {
            if (confirm("登録済みのスマホをすべて解除します。よろしいですか？")) { st.unpairAll(); refresh(); }
        });
        m.add(adv);
        m.addSeparator();
        MenuItem exit = new MenuItem("終了");
        exit.addActionListener(e -> EventQueue.invokeLater(() -> { if (admin.require("終了")) System.exit(0); }));
        m.add(exit);

        icon = new TrayIcon(drawIcon(), "SuicaKey", m);
        icon.setImageAutoSize(true);
        icon.addActionListener(e -> srv.requestAuth("PCからの認証依頼")); // ダブルクリックで依頼
        SystemTray.getSystemTray().add(icon);
        refresh();
    }

    private static BufferedImage drawIcon() {
        BufferedImage b = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = b.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(0x0F6E56));
        g.fillRoundRect(1, 1, 30, 30, 8, 8);
        g.setColor(Color.WHITE);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        g.drawString("S", 9, 24);
        g.dispose();
        return b;
    }

    @Override
    public void copy(String pw) {
        EventQueue.invokeLater(() -> {
            Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
            cb.setContents(new StringSelection(pw), null);
            icon.displayMessage("SuicaKey", "パスワードをコピーしました（30秒後に消去）", TrayIcon.MessageType.NONE);
            Timer t = new Timer(30_000, e -> {
                try {
                    Transferable tr = cb.getContents(null);
                    if (tr != null && tr.isDataFlavorSupported(DataFlavor.stringFlavor)
                            && pw.equals(tr.getTransferData(DataFlavor.stringFlavor))) {
                        cb.setContents(new StringSelection(""), null);
                    }
                } catch (Exception ignored) { }
            });
            t.setRepeats(false);
            t.start();
        });
    }

    @Override
    public void info(String msg) {
        EventQueue.invokeLater(() -> icon.displayMessage("SuicaKey", msg, TrayIcon.MessageType.INFO));
    }

    @Override
    public void refresh() {
        EventQueue.invokeLater(() -> {
            List<String> n = srv.connectedNames();
            conn.setLabel(n.isEmpty() ? "接続: なし（登録 " + st.phones().size() + "台）" : "接続中: " + String.join(", ", n));
            if (icon != null) icon.setToolTip(n.isEmpty() ? "SuicaKey（未接続）" : "SuicaKey（接続中）");
        });
    }

    private void showLog() {
        JTextArea a = new JTextArea(String.join("\n", st.logs()), 20, 60);
        a.setEditable(false);
        JOptionPane.showMessageDialog(null, new JScrollPane(a), "セキュリティ履歴", JOptionPane.PLAIN_MESSAGE);
    }

    /** Telegram: ボットトークン入力 → /start 送信を待ってチャットIDを自動取得 */
    private void setupTelegram() {
        String token = (String) JOptionPane.showInputDialog(null,
                "1. Telegramで @BotFather に /newbot を送り、ボットを作成\n"
                        + "2. 表示されたトークン（123456789:AA… の形式）を貼り付け",
                "Telegram設定（1/2）", JOptionPane.PLAIN_MESSAGE, null, null, "");
        if (token == null) return;
        token = token.trim();
        if (!Notifier.TOKEN.matcher(token).matches()) { info("エラーです"); return; }
        if (JOptionPane.showConfirmDialog(null,
                "3. Telegramで作成したボットを開き、/start を送信してください\n4. 送信したら OK を押してください",
                "Telegram設定（2/2）", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        String tok = token;
        new Thread(() -> {
            String chat = Notifier.telegramChatId(tok);
            if (chat == null) {
                EventQueue.invokeLater(() -> {
                    String manual = JOptionPane.showInputDialog(null,
                            "エラーです",
                            "Telegram設定", JOptionPane.WARNING_MESSAGE);
                    if (manual != null && manual.trim().matches("-?\\d+|@[A-Za-z0-9_]{5,}")) saveTelegram(tok, manual.trim());
                });
                return;
            }
            saveTelegram(tok, chat);
        }).start();
    }

    private void saveTelegram(String token, String chat) {
        String u = Notifier.telegramUrl(token, chat);
        st.setWebhook(u);
        new Thread(() -> info(Notifier.send(u, "【SuicaKey】Telegram通知を設定しました。緊急PINが使われると、ここに位置情報付きで通知します。")
                ? "Telegramを設定しました（テスト通知を送信）" : "エラーです")).start();
    }

    private void editWebhook() {
        String cur = st.webhook();
        String v = (String) JOptionPane.showInputDialog(null,
                "緊急時の通知先URL（https）\n・Telegram: https://api.telegram.org/bot<トークン>/sendMessage?chat_id=<ID>\n・Discord / Slack の Webhook URL\n・ntfy の場合 https://ntfy.sh/推測されにくいトピック名\n空欄で通知なし",
                "緊急通知の送信先", JOptionPane.PLAIN_MESSAGE, null, null, cur);
        if (v == null) return;
        if (!v.isBlank() && !v.trim().startsWith("https://")) { info("エラーです"); return; }
        st.setWebhook(v);
        info(v.isBlank() ? "通知先を削除しました" : "通知先を保存しました（暗号化して保存）");
    }

    private static boolean confirm(String msg) {
        return JOptionPane.showConfirmDialog(null, msg, "SuicaKey", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION;
    }

    private static String exePath() { return ProcessHandle.current().info().command().orElse(null); }

    private static boolean autostartEnabled() {
        try {
            Process p = new ProcessBuilder("reg", "query", RUN_KEY, "/v", "SuicaKey").redirectErrorStream(true).start();
            p.getInputStream().readAllBytes();
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void setAutostart(boolean on) {
        try {
            String exe = exePath();
            ProcessBuilder pb = on
                    ? new ProcessBuilder("reg", "add", RUN_KEY, "/v", "SuicaKey", "/t", "REG_SZ", "/d", "\"" + exe + "\"", "/f")
                    : new ProcessBuilder("reg", "delete", RUN_KEY, "/v", "SuicaKey", "/f");
            Process p = pb.redirectErrorStream(true).start();
            p.getInputStream().readAllBytes();
            info(p.waitFor() == 0 ? (on ? "自動起動を有効にしました" : "自動起動を無効にしました") : "エラーです");
        } catch (Exception e) {
            info("エラーです");
        }
    }
}
