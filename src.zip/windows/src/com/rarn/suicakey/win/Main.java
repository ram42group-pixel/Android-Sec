package com.rarn.suicakey.win;

import java.awt.SystemTray;
import java.net.BindException;
import java.nio.file.Path;
import javax.swing.JOptionPane;

/** SuicaKey Windows常駐アプリ */
public final class Main {
    public static void main(String[] args) throws Exception {
        if (!SystemTray.isSupported()) {
            JOptionPane.showMessageDialog(null, "エラーです");
            return;
        }
        JdkPqc c = new JdkPqc();
        String base = System.getenv("LOCALAPPDATA");
        if (base == null) base = System.getProperty("user.home");
        Store st = new Store(Path.of(base, "SuicaKey", "state.dat"), new Dpapi(), c);
        try {
            st.load();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "エラーです");
            return;
        }
        Server srv = new Server(c, st);
        try {
            srv.start();
        } catch (BindException e) {
            JOptionPane.showMessageDialog(null, "エラーです");
            return;
        }
        Tray t = new Tray(srv, st, new Admin(c, st, srv));
        srv.ui = t;
        t.init();
    }
}
