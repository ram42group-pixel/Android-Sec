package com.rarn.suicakey.win;

import com.rarn.suicakey.core.Bytes;
import com.rarn.suicakey.core.Pqc;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.KEM;

/** JDK 25 標準の ML-KEM / ML-DSA / X448 / Ed448 / SHA3 を使う実装 */
public final class JdkPqc extends Pqc {
    public JdkPqc() { super(null); }

    @Override
    public KeyPair genMlKem768() throws GeneralSecurityException { return kpg("ML-KEM-768").generateKeyPair(); }

    @Override
    public KeyPair genMlDsa65() throws GeneralSecurityException { return kpg("ML-DSA-65").generateKeyPair(); }

    @Override
    public byte[][] encaps(PublicKey pk) throws GeneralSecurityException {
        KEM.Encapsulated e = KEM.getInstance(MLKEM).newEncapsulator(pk, Bytes.RNG).encapsulate();
        return new byte[][]{e.encapsulation(), e.key().getEncoded()};
    }

    @Override
    public byte[] decaps(PrivateKey sk, byte[] ct) throws GeneralSecurityException {
        return KEM.getInstance(MLKEM).newDecapsulator(sk).decapsulate(ct).getEncoded();
    }
}
