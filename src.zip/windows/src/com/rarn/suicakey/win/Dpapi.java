package com.rarn.suicakey.win;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_BYTE;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemoryLayout;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.StructLayout;
import java.lang.foreign.SymbolLookup;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;

/**
 * Windows DPAPI（CryptProtectData / CryptUnprotectData）を FFM API で直接呼ぶ。
 * 保存データは現在のWindowsアカウントでしか復号できない。
 */
public final class Dpapi implements Store.Protector {
    private static final StructLayout BLOB = MemoryLayout.structLayout(
            JAVA_INT.withName("cbData"), MemoryLayout.paddingLayout(4), ADDRESS.withName("pbData"));
    private static final int UI_FORBIDDEN = 0x1;
    private static final byte[] ENTROPY = "SuicaKey/1 DPAPI entropy".getBytes(StandardCharsets.US_ASCII);

    private final MethodHandle protect, unprotect, localFree;

    public Dpapi() {
        Linker l = Linker.nativeLinker();
        SymbolLookup crypt = SymbolLookup.libraryLookup("crypt32", Arena.global());
        SymbolLookup k32 = SymbolLookup.libraryLookup("kernel32", Arena.global());
        FunctionDescriptor fd = FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS, ADDRESS, JAVA_INT, ADDRESS);
        protect = l.downcallHandle(crypt.find("CryptProtectData").orElseThrow(), fd);
        unprotect = l.downcallHandle(crypt.find("CryptUnprotectData").orElseThrow(), fd);
        localFree = l.downcallHandle(k32.find("LocalFree").orElseThrow(), FunctionDescriptor.of(ADDRESS, ADDRESS));
    }

    @Override
    public byte[] protect(byte[] data) throws Exception { return call(protect, data); }

    @Override
    public byte[] unprotect(byte[] data) throws Exception { return call(unprotect, data); }

    private byte[] call(MethodHandle h, byte[] data) throws Exception {
        try (Arena a = Arena.ofConfined()) {
            MemorySegment buf = a.allocate(Math.max(1, data.length));
            MemorySegment.copy(data, 0, buf, JAVA_BYTE, 0, data.length);
            MemorySegment in = a.allocate(BLOB);
            in.set(JAVA_INT, 0, data.length);
            in.set(ADDRESS, 8, buf);

            MemorySegment ebuf = a.allocate(ENTROPY.length);
            MemorySegment.copy(ENTROPY, 0, ebuf, JAVA_BYTE, 0, ENTROPY.length);
            MemorySegment ent = a.allocate(BLOB);
            ent.set(JAVA_INT, 0, ENTROPY.length);
            ent.set(ADDRESS, 8, ebuf);

            MemorySegment out = a.allocate(BLOB);
            int ok;
            try {
                ok = (int) h.invoke(in, MemorySegment.NULL, ent, MemorySegment.NULL, MemorySegment.NULL, UI_FORBIDDEN, out);
            } catch (Throwable t) {
                throw new Exception(t);
            } finally {
                buf.fill((byte) 0);
            }
            if (ok == 0) throw new Exception("DPAPI失敗");
            int n = out.get(JAVA_INT, 0);
            MemorySegment p = out.get(ADDRESS, 8).reinterpret(n);
            byte[] r = p.toArray(JAVA_BYTE);
            p.fill((byte) 0);
            try { localFree.invoke(p); } catch (Throwable ignored) { }
            return r;
        }
    }
}
