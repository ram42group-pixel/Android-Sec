package com.rarn.suicakey.win;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.rarn.suicakey.core.Bytes;
import com.rarn.suicakey.core.PairCtx;
import com.rarn.suicakey.core.Proto;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/** QR表示 → 確認コード照合 → 承認 */
final class PairWindow extends JFrame implements PairCtx.Listener {
    private final Server srv;
    private final PairCtx ctx;
    private final JLabel status = new JLabel("スマホのSuicaKeyで「PCとペアリング」を押し、このQRを読み取ってください", SwingConstants.CENTER);
    private final JLabel code = new JLabel(" ", SwingConstants.CENTER);
    private final JButton ok = new JButton("番号が一致");
    private final JButton ng = new JButton("中止");

    PairWindow(Server srv) throws Exception {
        super("SuicaKey ペアリング（2分間有効）");
        this.srv = srv;
        byte[] psk = Bytes.rnd(32);
        String qr = "SK1:" + lanIp() + ":" + Proto.PORT + ":" + Bytes.b64u(psk) + ":"
                + Bytes.b64u(Bytes.slice(srv.st.pc().fp, 0, 16));
        ctx = new PairCtx(psk, 120_000, this);
        srv.pairing = ctx;

        JLabel img = new JLabel(new ImageIcon(render(qr, 360)));
        code.setFont(code.getFont().deriveFont(Font.BOLD, 40f));
        ok.setEnabled(false);
        ok.addActionListener(e -> { ok.setEnabled(false); ctx.userConfirm(true); status.setText("登録中…"); });
        ng.addActionListener(e -> dispose());

        JPanel btns = new JPanel(new GridLayout(1, 2, 12, 0));
        btns.add(ok);
        btns.add(ng);
        JPanel south = new JPanel(new GridLayout(3, 1, 0, 8));
        south.setBorder(BorderFactory.createEmptyBorder(8, 16, 16, 16));
        south.add(status);
        south.add(code);
        south.add(btns);
        add(img, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) { ctx.end(); if (srv.pairing == ctx) srv.pairing = null; }
        });
        Timer t = new Timer(120_000, e -> dispose());
        t.setRepeats(false);
        t.start();
        pack();
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        setVisible(true);
    }

    static BufferedImage render(String text, int size) throws Exception {
        BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size,
                Map.of(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M, EncodeHintType.MARGIN, 2));
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++) img.setRGB(x, y, m.get(x, y) ? 0x000000 : 0xFFFFFF);
        return img;
    }

    static String lanIp() {
        try (DatagramSocket s = new DatagramSocket()) {
            s.connect(InetAddress.getByName("10.255.255.255"), 1);
            String ip = s.getLocalAddress().getHostAddress();
            if (!ip.startsWith("0.")) return ip;
        } catch (Exception ignored) { }
        try { return InetAddress.getLocalHost().getHostAddress(); } catch (Exception e) { return "127.0.0.1"; }
    }

    @Override
    public void code(int c, String name) {
        SwingUtilities.invokeLater(() -> {
            code.setText(String.format("%03d %03d", c / 1000, c % 1000));
            status.setText("「" + name + "」に同じ番号が表示されているか確認してください");
        });
    }

    @Override
    public void verified() {
        SwingUtilities.invokeLater(() -> {
            ok.setEnabled(true);
            status.setText("スマホ側で承認されました。番号が一致していれば押してください");
        });
    }

    @Override
    public void done(String name) {
        SwingUtilities.invokeLater(() -> {
            status.setText("ペアリング完了: " + name);
            Timer t = new Timer(1500, e -> dispose());
            t.setRepeats(false);
            t.start();
        });
    }

    @Override
    public void ended() { }
}
