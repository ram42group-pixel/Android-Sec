package com.rarn.suicakey.win;

import com.rarn.suicakey.core.Bytes;
import com.rarn.suicakey.core.Pqc;
import com.rarn.suicakey.core.Proto;
import com.rarn.suicakey.core.Vault;
import java.awt.Cursor;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

/**
 * 管理者パスワードとキーファイル（USB等の外部メモリ上の特定ファイル）。
 *   メニュー保護 : 管理者パスワード（PBKDF2-HMAC-SHA3-512 60万回で照合・5回でロック）
 *   回復        : キーファイル内容の SHA3-512 ＋ 管理者パスワード → マスター鍵 M
 */
final class Admin {
    static final String DEFAULT_NAME = "SuicaKey.key";
    /** 総当たり対策：管理者パスワードの照合は5秒に1回まで */
    static final long MIN_INTERVAL_MS = 5_000L;
    private long lastNano;
    private final Pqc c;
    private final Store st;
    private final Server srv;

    Admin(Pqc c, Store st, Server srv) { this.c = c; this.st = st; this.srv = srv; }

    boolean configured() { return st.adminConfigured(); }

    // ───────── 共通ダイアログ ─────────
    private static char[] askPw(String title, String msg) {
        JPasswordField f = new JPasswordField(28);
        int r = JOptionPane.showConfirmDialog(null, new Object[]{msg, f}, title, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        return r == JOptionPane.OK_OPTION ? f.getPassword() : null;
    }

    private static void msg(String m) { JOptionPane.showMessageDialog(null, m, "SuicaKey 管理", JOptionPane.INFORMATION_MESSAGE); }

    private static boolean yes(String m) {
        return JOptionPane.showConfirmDialog(null, m, "SuicaKey 管理", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION;
    }

    /** 前回の照合から5秒未満なら照合せずエラー（単調時計と保存済み時刻の両方で判定） */
    private boolean tooSoon() {
        long now = System.currentTimeMillis();
        long dw = now - st.adminLastTry();
        boolean soon = (lastNano != 0 && System.nanoTime() - lastNano < MIN_INTERVAL_MS * 1_000_000L)
                || (dw >= 0 && dw < MIN_INTERVAL_MS);
        if (soon) { msg("エラーです"); return true; }
        lastNano = System.nanoTime();
        st.markAdminTry(now);
        return false;
    }

    private boolean lockedOut() {
        long left = st.adminLock() - Proto.now();
        if (left > 0) { msg("エラーです"); return true; }
        return false;
    }

    /** 計算中は砂時計カーソル（PBKDF2 約1秒） */
    private static <T> T busy(java.util.concurrent.Callable<T> f) throws Exception {
        java.awt.Window w = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getActiveWindow();
        if (w != null) w.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        try { return f.call(); } finally { if (w != null) w.setCursor(Cursor.getDefaultCursor()); }
    }

    // ───────── メニュー保護 ─────────
    /** 管理者パスワードで保護された操作の前に呼ぶ。未設定なら許可（初期設定を促す） */
    boolean require(String what) {
        if (!configured()) return true;
        if (lockedOut()) return false;
        char[] pw = askPw("管理者パスワード", what + "には管理者パスワードが必要です");
        if (pw == null) return false;
        if (tooSoon()) { Arrays.fill(pw, '\0'); return false; }
        try {
            String s = new String(pw);
            boolean ok = busy(() -> Bytes.eq(Vault.adminVerifier(c, s, st.adminSalt()), st.adminVer()));
            st.adminResult(ok);
            if (!ok) msg("エラーです");
            return ok;
        } catch (Exception e) {
            return false;
        } finally {
            Arrays.fill(pw, '\0');
        }
    }

    // ───────── 初期設定 / 復元 ─────────
    void setup() {
        if (configured()) {
            if (!yes("管理者パスワードまたはキーファイルを変更すると、保護対象のパスワードも変わります。\n"
                    + "（変更前に「パスワードを表示」で現在の値を控え、保護対象側も変更してください）\n続けますか？")) return;
            if (!require("設定の変更")) return;
        }
        char[] p1 = askPw("初期設定（1/3）管理者パスワード",
                "管理者パスワード（" + Vault.MIN_ADMIN_PW + "文字以上・推測されにくいもの）\n※復元にも使います。忘れると回復できません");
        if (p1 == null) return;
        if (p1.length < Vault.MIN_ADMIN_PW) { msg("エラーです"); return; }
        char[] p2 = askPw("初期設定（1/3）確認", "もう一度入力してください");
        if (p2 == null || !Arrays.equals(p1, p2)) { msg("エラーです"); return; }
        Arrays.fill(p2, '\0');

        Object[] opts = {"USBに新しいキーファイルを作る（推奨）", "既存のキーファイルを使う（PC再構築時の復元）", "キャンセル"};
        int k = JOptionPane.showOptionDialog(null,
                "回復用キーファイル：外部メモリ上の特定ファイルの内容をSHA3-512でハッシュ化して使います。\n"
                        + "キーファイルと管理者パスワードの両方があれば、スマホやPCを失っても同じパスワードを再現できます。",
                "初期設定（2/3）キーファイル", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opts, opts[0]);
        File kf = k == 0 ? createKeyfile() : k == 1 ? chooseFile(null) : null;
        if (kf == null) return;

        try {
            byte[] content = readKeyfile(kf);
            String pw = new String(p1);
            byte[] m = busy(() -> Vault.master(c, Vault.keyfileHash(c, content), pw));
            Bytes.wipe(content);
            byte[] check = Vault.check(c, m);
            byte[] old = st.mCheck();
            byte[] salt = Bytes.rnd(32);
            byte[] ver = busy(() -> Vault.adminVerifier(c, pw, salt));
            boolean changed = old != null && !Bytes.eq(old, check);
            if (changed) st.clearWraps();
            st.setAdmin(salt, ver, check, kf.getName());
            st.log(changed ? "管理者設定を変更（マスター鍵が変化・全端末の再登録が必要）" : "管理者設定を保存");
            st.save();
            if (yes("初期設定（3/3）\n続けて、スマホでSuicaとPINを登録しますか？\n"
                    + "（OK後、スマホに通知が届きます。5分以内にSuicaタッチ→PIN）")) {
                srv.armRegister(m);
                srv.requestAuth("カード/PINの登録");
            } else {
                Bytes.wipe(m);
            }
        } catch (Exception e) {
            msg("エラーです");
        } finally {
            Arrays.fill(p1, '\0');
        }
    }

    /** USB等の外部メモリに乱数4096バイトのキーファイルを作成 */
    private File createKeyfile() {
        JFileChooser ch = new JFileChooser(firstRemovableRoot());
        ch.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        ch.setDialogTitle("キーファイルの保存先（USBメモリ等）を選択");
        if (ch.showSaveDialog(null) != JFileChooser.APPROVE_OPTION) return null;
        File dir = ch.getSelectedFile();
        if (dir.toPath().getRoot() != null && dir.toPath().getRoot().toString().toUpperCase().startsWith("C:")
                && !yes("Cドライブ（PC内部）が選ばれています。PCと一緒に盗まれると意味がありません。\n本当にここに保存しますか？")) return null;
        String name = JOptionPane.showInputDialog(null,
                "キーファイル名（復元時にこの名前で探します。目立たない名前でも構いません）", DEFAULT_NAME);
        if (name == null || name.isBlank() || name.contains("/") || name.contains("\\")) return null;
        File f = new File(dir, name.trim());
        if (f.exists()) { msg("エラーです"); return null; }
        byte[] rnd = Bytes.rnd(4096);
        try {
            Files.write(f.toPath(), rnd, StandardOpenOption.CREATE_NEW);
            if (!Bytes.eq(Files.readAllBytes(f.toPath()), rnd)) throw new Exception("書き込み確認に失敗");
            msg("キーファイルを作成しました：\n" + f + "\n\n・このファイルは絶対に編集しないでください（1バイト違っても回復不能）\n"
                    + "・USBはPCと別の安全な場所に保管し、可能ならコピーをもう1本作ってください");
            return f;
        } catch (Exception e) {
            msg("エラーです");
            return null;
        } finally {
            Bytes.wipe(rnd);
        }
    }

    private static File firstRemovableRoot() {
        for (File r : File.listRoots()) {
            String p = r.getPath().toUpperCase();
            if (!p.startsWith("C:") && r.canRead()) return r;
        }
        return null;
    }

    private static File chooseFile(File start) {
        JFileChooser ch = new JFileChooser(start != null ? start : firstRemovableRoot());
        ch.setDialogTitle("キーファイルを選択");
        ch.setFileSelectionMode(JFileChooser.FILES_ONLY);
        return ch.showOpenDialog(null) == JFileChooser.APPROVE_OPTION ? ch.getSelectedFile() : null;
    }

    private static byte[] readKeyfile(File f) throws Exception {
        long n = Files.size(f.toPath());
        if (n < 32) throw new Exception("ファイルが小さすぎます（32バイト以上必要）");
        if (n > Vault.MAX_KEYFILE) throw new Exception("ファイルが大きすぎます（64MBまで）");
        return Files.readAllBytes(f.toPath());
    }

    /** 全ドライブのルートから、登録したファイル名のキーファイルを探す */
    private File findKeyfile() {
        String name = st.keyfileName().isEmpty() ? DEFAULT_NAME : st.keyfileName();
        for (File r : File.listRoots()) {
            File f = new File(r, name);
            if (f.isFile()) return f;
        }
        msg("エラーです");
        return chooseFile(null);
    }

    /** キーファイル＋管理者パスワードから M を復元（照合値で検証） */
    private byte[] recoverM(String purpose) {
        if (!configured()) { msg("エラーです"); return null; }
        if (lockedOut()) return null;
        File kf = findKeyfile();
        if (kf == null) return null;
        char[] pw = askPw("管理者パスワード", purpose + "：管理者パスワードを入力してください");
        if (pw == null) return null;
        if (tooSoon()) { Arrays.fill(pw, '\0'); return null; }
        try {
            byte[] content = readKeyfile(kf);
            String s = new String(pw);
            byte[] m = busy(() -> Vault.master(c, Vault.keyfileHash(c, content), s));
            Bytes.wipe(content);
            boolean ok = Bytes.eq(Vault.check(c, m), st.mCheck());
            st.adminResult(ok);
            if (!ok) { Bytes.wipe(m); msg("エラーです"); return null; }
            st.log(purpose + "（キーファイル使用）");
            st.save();
            return m;
        } catch (Exception e) {
            msg("エラーです");
            return null;
        } finally {
            Arrays.fill(pw, '\0');
        }
    }

    // ───────── 回復操作 ─────────
    /** スマホ紛失・機種変更・PIN変更時：新しいSuica×PINに M を包み直す */
    void register() {
        byte[] m = recoverM("カード/PINの登録");
        if (m == null) return;
        srv.armRegister(m);
        srv.requestAuth("カード/PINの登録");
        msg("スマホに通知を送りました。5分以内にSuicaタッチ→PINで登録が完了します。\n"
                + "（スマホが未接続なら、先に新しいスマホを「ペアリング」してください）");
    }

    /** スマホがない緊急時：その場でパスワードをコピー */
    void showPassword(Server.Ui ui) {
        byte[] m = recoverM("パスワードの緊急表示");
        if (m == null) return;
        try {
            String pw = Vault.password(c, m);
            Object[] o = {"コピー（30秒で消去）", "表示する", "閉じる"};
            int r = JOptionPane.showOptionDialog(null, "パスワードを取り出しました", "緊急表示",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, o, o[0]);
            if (r == 0) ui.copy(pw);
            else if (r == 1) JOptionPane.showMessageDialog(null, pw, "パスワード（画面を見られないよう注意）", JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            msg("エラーです");
        } finally {
            Bytes.wipe(m);
        }
    }

    /** PINの連続失敗によるロックを解除 */
    void unlockPhones() {
        if (!require("端末ロックの解除")) return;
        msg(st.unlockPhones() ? "解除しました" : "エラーです");
    }

    /** スマホなしで緊急停止を解除 */
    void unlockDuress() {
        if (st.duressUntil() <= Proto.now()) { msg("エラーです"); return; }
        if (!configured()) { msg("エラーです"); return; }
        if (!require("緊急停止の解除")) return;
        st.setDuressUntil(0);
        st.log("緊急停止を解除（管理者パスワード）");
        st.save();
        msg("緊急停止を解除しました");
    }
}
