package com.rarn.suicakey.win;

import com.rarn.suicakey.core.Bytes;
import com.rarn.suicakey.core.PcSide;
import com.rarn.suicakey.core.Pqc;
import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/** 秘密鍵・登録端末・履歴を DPAPI で暗号化して1ファイルに永続化 */
public final class Store implements PcSide.PcStore {
    public interface Protector {
        byte[] protect(byte[] b) throws Exception;
        byte[] unprotect(byte[] b) throws Exception;
    }

    private final Path file;
    private final Protector prot;
    private final Pqc c;
    private PcSide.PcKeys keys;
    private final Map<String, PcSide.PhoneRec> phones = new LinkedHashMap<>();
    private final List<String> logs = new ArrayList<>();
    /** 緊急停止の期限（エポック秒）。この間は本物の認証に無反応 */
    private long duressUntil;
    /** 緊急通知の送信先（Discord/Slack/ntfy のURL） */
    private String webhook = "";

    public synchronized long duressUntil() { return duressUntil; }
    public synchronized void setDuressUntil(long t) { duressUntil = t; save(); }
    public synchronized String webhook() { return webhook; }
    public synchronized void setWebhook(String w) { webhook = w == null ? "" : w.trim(); save(); }

    public Store(Path file, Protector prot, Pqc c) { this.file = file; this.prot = prot; this.c = c; }

    public synchronized void load() throws Exception {
        if (!Files.exists(file)) {
            keys = PcSide.PcKeys.generate(c);
            save();
            return;
        }
        byte[] raw = prot.unprotect(Files.readAllBytes(file));
        Properties p = new Properties();
        p.load(new StringReader(new String(raw, StandardCharsets.UTF_8)));
        Bytes.wipe(raw);
        PcSide.PcKeys k = new PcSide.PcKeys();
        k.kemSk = c.priv(Pqc.MLKEM, d(p, "pc.kem.sk")); k.kemPk = d(p, "pc.kem.pk");
        k.xSk = c.priv(Pqc.X448, d(p, "pc.x.sk")); k.xPk = d(p, "pc.x.pk");
        k.dsaSk = c.priv(Pqc.MLDSA, d(p, "pc.dsa.sk")); k.dsaPk = d(p, "pc.dsa.pk");
        k.edSk = c.priv(Pqc.ED448, d(p, "pc.ed.sk")); k.edPk = d(p, "pc.ed.pk");
        k.bind = d(p, "pc.bind");
        k.finish(c);
        keys = k;
        int np = Integer.parseInt(p.getProperty("ph.count", "0"));
        for (int i = 0; i < np; i++) {
            String q = "ph." + i + ".";
            PcSide.PhoneRec r = new PcSide.PhoneRec();
            r.id = d(p, q + "id"); r.name = p.getProperty(q + "name");
            r.dsaPk = d(p, q + "dsa"); r.edPk = d(p, q + "ed");
            r.psk = d(p, q + "psk"); r.n = Long.parseLong(p.getProperty(q + "n"));
            r.pend = p.containsKey(q + "pend") ? d(p, q + "pend") : null;
            r.wrap = p.containsKey(q + "wrap") ? d(p, q + "wrap") : null;
            r.locked = Boolean.parseBoolean(p.getProperty(q + "locked"));
            r.fails = Integer.parseInt(p.getProperty(q + "fails", "0"));
            r.pinLocked = Boolean.parseBoolean(p.getProperty(q + "plock", "false"));
            phones.put(Bytes.hex(r.id), r);
        }
        duressUntil = Long.parseLong(p.getProperty("duress.until", "0"));
        if (p.containsKey("admin.ver")) {
            adminSalt = d(p, "admin.salt"); adminVer = d(p, "admin.ver"); mCheck = d(p, "admin.mcheck");
            kfName = p.getProperty("admin.kfname", "");
        }
        adminFails = Integer.parseInt(p.getProperty("admin.fails", "0"));
        adminLock = Long.parseLong(p.getProperty("admin.lock", "0"));
        adminLastTry = Long.parseLong(p.getProperty("admin.lasttry", "0"));
        webhook = p.getProperty("notify.url", "");
        int nl = Integer.parseInt(p.getProperty("log.count", "0"));
        for (int i = 0; i < nl; i++) logs.add(p.getProperty("log." + i));
    }

    private static byte[] d(Properties p, String k) { return Bytes.unb64(p.getProperty(k)); }

    @Override
    public synchronized void save() {
        try {
            Properties p = new Properties();
            p.setProperty("pc.kem.sk", Bytes.b64(keys.kemSk.getEncoded())); p.setProperty("pc.kem.pk", Bytes.b64(keys.kemPk));
            p.setProperty("pc.x.sk", Bytes.b64(keys.xSk.getEncoded())); p.setProperty("pc.x.pk", Bytes.b64(keys.xPk));
            p.setProperty("pc.dsa.sk", Bytes.b64(keys.dsaSk.getEncoded())); p.setProperty("pc.dsa.pk", Bytes.b64(keys.dsaPk));
            p.setProperty("pc.ed.sk", Bytes.b64(keys.edSk.getEncoded())); p.setProperty("pc.ed.pk", Bytes.b64(keys.edPk));
            p.setProperty("pc.bind", Bytes.b64(keys.bind));
            int i = 0;
            for (PcSide.PhoneRec r : phones.values()) {
                String q = "ph." + i++ + ".";
                p.setProperty(q + "id", Bytes.b64(r.id)); p.setProperty(q + "name", r.name);
                p.setProperty(q + "dsa", Bytes.b64(r.dsaPk)); p.setProperty(q + "ed", Bytes.b64(r.edPk));
                p.setProperty(q + "psk", Bytes.b64(r.psk)); p.setProperty(q + "n", Long.toString(r.n));
                if (r.pend != null) p.setProperty(q + "pend", Bytes.b64(r.pend));
                if (r.wrap != null) p.setProperty(q + "wrap", Bytes.b64(r.wrap));
                p.setProperty(q + "locked", Boolean.toString(r.locked));
                p.setProperty(q + "fails", Integer.toString(r.fails));
                p.setProperty(q + "plock", Boolean.toString(r.pinLocked));
            }
            p.setProperty("ph.count", Integer.toString(phones.size()));
            for (int j = 0; j < logs.size(); j++) p.setProperty("log." + j, logs.get(j));
            p.setProperty("log.count", Integer.toString(logs.size()));
            p.setProperty("duress.until", Long.toString(duressUntil));
            if (adminVer != null) {
                p.setProperty("admin.salt", Bytes.b64(adminSalt)); p.setProperty("admin.ver", Bytes.b64(adminVer));
                p.setProperty("admin.mcheck", Bytes.b64(mCheck)); p.setProperty("admin.kfname", kfName);
            }
            p.setProperty("admin.fails", Integer.toString(adminFails));
            p.setProperty("admin.lock", Long.toString(adminLock));
            p.setProperty("admin.lasttry", Long.toString(adminLastTry));
            p.setProperty("notify.url", webhook);

            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (OutputStreamWriter w = new OutputStreamWriter(bo, StandardCharsets.UTF_8)) { p.store(w, null); }
            byte[] raw = bo.toByteArray();
            byte[] enc = prot.protect(raw);
            Bytes.wipe(raw);
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.write(tmp, enc);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception e) {
            System.err.println("save failed: " + e);
        }
    }

    @Override public synchronized PcSide.PcKeys pc() { return keys; }
    @Override public synchronized PcSide.PhoneRec find(byte[] id) { return phones.get(Bytes.hex(id)); }
    @Override public synchronized void put(PcSide.PhoneRec r) { phones.put(Bytes.hex(r.id), r); }

    @Override
    public synchronized void log(String msg) {
        logs.add(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + "  " + msg);
        while (logs.size() > 200) logs.remove(0);
    }

    public synchronized List<String> logs() { return new ArrayList<>(logs); }
    public synchronized List<PcSide.PhoneRec> phones() { return new ArrayList<>(phones.values()); }

    public synchronized void unpairAll() { phones.clear(); log("全端末のペアリングを解除"); save(); }

    // ── 管理者 ──
    private byte[] adminSalt, adminVer, mCheck;
    private String kfName = "";
    private int adminFails;
    private long adminLock;
    private long adminLastTry;

    public synchronized long adminLastTry() { return adminLastTry; }
    /** 照合の直前に記録して即保存（再起動しても5秒制限が続く） */
    public synchronized void markAdminTry(long ms) { adminLastTry = ms; save(); }

    public synchronized boolean adminConfigured() { return adminVer != null; }
    public synchronized byte[] adminSalt() { return adminSalt; }
    public synchronized byte[] adminVer() { return adminVer; }
    public synchronized byte[] mCheck() { return mCheck; }
    public synchronized String keyfileName() { return kfName; }
    public synchronized int adminFails() { return adminFails; }
    public synchronized long adminLock() { return adminLock; }

    public synchronized void setAdmin(byte[] salt, byte[] ver, byte[] check, String name) {
        adminSalt = salt; adminVer = ver; mCheck = check; kfName = name == null ? "" : name;
        adminFails = 0; adminLock = 0;
        save();
    }

    public synchronized void adminResult(boolean ok) {
        if (ok) { adminFails = 0; adminLock = 0; }
        else {
            adminFails++;
            if (adminFails >= 5) adminLock = System.currentTimeMillis() / 1000 + 300L * (1L << Math.min(adminFails - 5, 8));
            log("管理者パスワードの誤り（" + adminFails + "回目）");
        }
        save();
    }

    /** 連続失敗ロックの解除 */
    public synchronized boolean unlockPhones() {
        boolean any = false;
        for (PcSide.PhoneRec r : phones.values()) { if (r.pinLocked || r.fails > 0) any = true; r.pinLocked = false; r.fails = 0; }
        if (any) { log("連続失敗ロックを解除（管理者）"); save(); }
        return any;
    }

    /** 包みの全削除（M が変わったとき） */
    public synchronized void clearWraps() {
        for (PcSide.PhoneRec r : phones.values()) r.wrap = null;
        save();
    }
}
