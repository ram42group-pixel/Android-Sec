package com.rarn.suicakey.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;

/** 位置指定フィールドのメッセージ: [type u8][count u16]{[len u32][bytes]}* */
public final class Msg {
    public final int type;
    private final byte[][] f;

    public Msg(int type, byte[]... fields) {
        this.type = type & 0xff;
        this.f = fields;
    }

    public int n() { return f.length; }

    public byte[] get(int i) { return f[i]; }

    public Msg with(byte[]... more) {
        byte[][] a = Arrays.copyOf(f, f.length + more.length);
        System.arraycopy(more, 0, a, f.length, more.length);
        return new Msg(type, a);
    }

    public Msg head(int k) { return new Msg(type, Arrays.copyOf(f, k)); }

    public byte[] encode() {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(type);
        o.write(f.length >>> 8);
        o.write(f.length);
        for (byte[] x : f) {
            int l = x.length;
            o.write(l >>> 24); o.write(l >>> 16); o.write(l >>> 8); o.write(l);
            o.write(x, 0, l);
        }
        return o.toByteArray();
    }

    public static Msg decode(byte[] b) throws IOException {
        if (b.length < 3) throw new IOException("short");
        int type = b[0] & 0xff;
        int cnt = ((b[1] & 0xff) << 8) | (b[2] & 0xff);
        if (cnt > 32) throw new IOException("fields");
        byte[][] f = new byte[cnt][];
        int p = 3;
        for (int i = 0; i < cnt; i++) {
            if (p + 4 > b.length) throw new IOException("len");
            int l = ((b[p] & 0xff) << 24) | ((b[p + 1] & 0xff) << 16) | ((b[p + 2] & 0xff) << 8) | (b[p + 3] & 0xff);
            p += 4;
            if (l < 0 || l > b.length - p) throw new IOException("len");
            f[i] = Arrays.copyOfRange(b, p, p + l);
            p += l;
        }
        if (p != b.length) throw new IOException("trailing");
        return new Msg(type, f);
    }
}
