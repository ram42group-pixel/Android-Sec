package com.rarn.suicakey.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

/** バイト列ユーティリティ */
public final class Bytes {
    private Bytes() {}

    public static final SecureRandom RNG = new SecureRandom();

    public static byte[] rnd(int n) {
        byte[] b = new byte[n];
        RNG.nextBytes(b);
        return b;
    }

    public static byte[] cat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }

    public static byte[] slice(byte[] b, int from, int to) {
        return Arrays.copyOfRange(b, from, to);
    }

    public static byte[] u64(long v) {
        byte[] b = new byte[8];
        for (int i = 7; i >= 0; i--) { b[i] = (byte) v; v >>>= 8; }
        return b;
    }

    public static long u64(byte[] b) {
        if (b.length != 8) throw new IllegalArgumentException("u64");
        long v = 0;
        for (byte x : b) v = (v << 8) | (x & 0xff);
        return v;
    }

    /** 定数時間比較 */
    public static boolean eq(byte[] a, byte[] b) {
        return a != null && b != null && MessageDigest.isEqual(a, b);
    }

    public static void wipe(byte[]... arrs) {
        for (byte[] a : arrs) if (a != null) Arrays.fill(a, (byte) 0);
    }

    public static byte[] utf8(String s) { return s.getBytes(StandardCharsets.UTF_8); }

    public static String str(byte[] b) { return new String(b, StandardCharsets.UTF_8); }

    public static String b64u(byte[] b) { return Base64.getUrlEncoder().withoutPadding().encodeToString(b); }

    public static byte[] unb64u(String s) { return Base64.getUrlDecoder().decode(s); }

    public static String b64(byte[] b) { return Base64.getEncoder().encodeToString(b); }

    public static byte[] unb64(String s) { return Base64.getDecoder().decode(s); }

    public static String hex(byte[] b) {
        char[] h = "0123456789abcdef".toCharArray();
        char[] o = new char[b.length * 2];
        for (int i = 0; i < b.length; i++) { o[2 * i] = h[(b[i] >> 4) & 15]; o[2 * i + 1] = h[b[i] & 15]; }
        return new String(o);
    }
}
