package com.rarn.suicakey.core;

import static com.rarn.suicakey.core.Proto.label;

/**
 * マスター鍵 M と鍵の包み直し。
 *
 *   M        = HKDF-SHA3-512( salt = SHA3-512(キーファイル内容),
 *                             ikm  = PBKDF2-HMAC-SHA3-512(管理者パスワード, 60万回) )
 *   パスワード = HKDF(M)                       … PCやスマホが変わっても同じ
 *   包み      = AES-256-GCM( HKDF(PC秘密, Suica×PIN×スマホ鍵の素材), M )
 *
 * 普段は「包み」を開いて M を得る。スマホ紛失・PC再構築時は キーファイル＋管理者パスワード から M を再計算する。
 */
public final class Vault {
    private Vault() {}

    public static final int ITER = 600_000;
    public static final int MIN_ADMIN_PW = 12;
    public static final long MAX_KEYFILE = 64L * 1024 * 1024;

    public static byte[] keyfileHash(Pqc c, byte[] content) throws Exception {
        return c.sha3(label("keyfile"), content);
    }

    public static byte[] master(Pqc c, byte[] kfHash, String adminPw) throws Exception {
        byte[] pw = Bytes.cat(label("admin-master"), Bytes.utf8(adminPw));
        byte[] k = c.pbkdf2(pw, Bytes.slice(kfHash, 0, 32), ITER, 64);
        byte[] m = c.hkdf(kfHash, k, label("master"), 64);
        Bytes.wipe(pw, k);
        return m;
    }

    /** 回復入力が正しいかの確認値（キーファイルが乱数なので総当たり不能） */
    public static byte[] check(Pqc c, byte[] m) throws Exception { return c.sha3(label("mcheck"), m); }

    public static String password(Pqc c, byte[] m) throws Exception {
        byte[] p = c.hkdf(label("pw-salt"), m, label("password"), 24);
        String s = Bytes.b64u(p);
        Bytes.wipe(p);
        return s;
    }

    /** 管理者パスワードの照合値（メニュー保護用） */
    public static byte[] adminVerifier(Pqc c, String adminPw, byte[] salt) throws Exception {
        byte[] pw = Bytes.cat(label("admin-verify"), Bytes.utf8(adminPw));
        byte[] v = c.pbkdf2(pw, salt, ITER, 64);
        Bytes.wipe(pw);
        return v;
    }

    private static byte[] wrapKey(Pqc c, byte[] bind, byte[] material) throws Exception {
        return c.hkdf(bind, material, label("wrap"), 32);
    }

    public static byte[] wrap(Pqc c, byte[] bind, byte[] material, byte[] phoneId, byte[] m) throws Exception {
        byte[] k = wrapKey(c, bind, material);
        byte[] nonce = Bytes.rnd(12);
        byte[] ct = c.gcm(true, k, nonce, Bytes.cat(label("wrap-aad"), phoneId), m);
        Bytes.wipe(k);
        return Bytes.cat(nonce, ct);
    }

    /** @return M（カード/PINが違えば null） */
    public static byte[] unwrap(Pqc c, byte[] bind, byte[] material, byte[] phoneId, byte[] blob) {
        byte[] k = null;
        try {
            k = wrapKey(c, bind, material);
            return c.gcm(false, k, Bytes.slice(blob, 0, 12), Bytes.cat(label("wrap-aad"), phoneId), Bytes.slice(blob, 12, blob.length));
        } catch (Exception e) {
            return null;
        } finally {
            Bytes.wipe(k);
        }
    }
}
