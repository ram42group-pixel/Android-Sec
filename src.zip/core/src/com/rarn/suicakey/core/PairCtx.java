package com.rarn.suicakey.core;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/** PC側のペアリング待受（1回限り・時間制限・失敗3回で終了） */
public final class PairCtx {
    public interface Listener {
        void code(int code, String phoneName);
        void verified();
        void done(String phoneName);
        void ended();
    }

    public final byte[] psk;
    private final long until;
    private final Listener l;
    private int bad;
    private volatile boolean finished;
    private final CompletableFuture<Boolean> user = new CompletableFuture<>();

    public PairCtx(byte[] psk, long ttlMs, Listener l) {
        this.psk = psk; this.until = System.currentTimeMillis() + ttlMs; this.l = l;
    }

    public boolean active() { return !finished && System.currentTimeMillis() < until; }

    private boolean claimed;

    synchronized void bad() { if (++bad >= 3 || claimed) end(); }

    /** 最初に正しく接続した1台だけが進める（同時接続による便乗登録を防ぐ） */
    synchronized boolean claim() {
        if (claimed || finished) return false;
        claimed = true;
        return true;
    }

    public void userConfirm(boolean ok) { user.complete(ok); }

    boolean awaitUser(long ms) {
        try { return user.get(ms, TimeUnit.MILLISECONDS); } catch (Exception e) { return false; }
    }

    void code(int code, String name) { if (l != null) l.code(code, name); }
    void verified() { if (l != null) l.verified(); }
    void done(String name) { finished = true; Bytes.wipe(psk); if (l != null) l.done(name); }

    public void end() {
        if (finished) return;
        finished = true;
        Bytes.wipe(psk);
        user.complete(false);
        if (l != null) l.ended();
    }
}
