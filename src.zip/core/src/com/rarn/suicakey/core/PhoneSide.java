package com.rarn.suicakey.core;

import static com.rarn.suicakey.core.Proto.label;

import java.security.KeyPair;
import java.security.PublicKey;

/** スマホ側プロトコル */
public final class PhoneSide {
    private PhoneSide() {}

    public interface CodeConfirm { boolean confirm(int code) throws Exception; }

    public static final class PairResult {
        public byte[] pcKem, pcX, pcDsa, pcEd, pcFp, psk0, phoneFp;
        public String host;
        public int port;
    }

    public static final class Session {
        public final Channel ch;
        public final byte[] t2;
        Session(Channel ch, byte[] t2) { this.ch = ch; this.t2 = t2; }
    }

    public static final class Qr {
        public final String host; public final int port; public final byte[] psk, fp16;
        Qr(String h, int p, byte[] k, byte[] f) { host = h; port = p; psk = k; fp16 = f; }
    }

    /** QR: SK1:host:port:psk(b64url 32B):pcFp先頭16B(b64url) */
    public static Qr parseQr(String s) {
        String[] p = s.trim().split(":");
        if (p.length != 5 || !"SK1".equals(p[0])) throw new IllegalArgumentException("SuicaKeyのQRではありません");
        byte[] psk = Bytes.unb64u(p[3]), fp = Bytes.unb64u(p[4]);
        if (psk.length != 32 || fp.length != 16) throw new IllegalArgumentException("QRが不正です");
        return new Qr(p[1], Integer.parseInt(p[2]), psk, fp);
    }

    public static byte[] phoneFp(Pqc c, byte[] dsaPk, byte[] edPk) throws Exception {
        return c.sha3(Proto.bundle(dsaPk, edPk));
    }

    /** ペアリング（QRで受け取った光学共有鍵で全メッセージを認証） */
    public static PairResult pair(Pqc c, IO io, Qr qr, KeyPair dsa, KeyPair ed, String name, CodeConfirm cb) throws Exception {
        byte[] kpair = c.hkdf(Proto.ALG, qr.psk, label("pair"), 64);
        byte[] dsaPk = dsa.getPublic().getEncoded(), edPk = ed.getPublic().getEncoded();

        Msg p1 = new Msg(Proto.PAIR1, dsaPk, edPk, Bytes.rnd(32), Bytes.utf8(name));
        byte[] tp1 = c.sha3(label("P1"), p1.encode());
        io.write(p1.with(c.hmac(kpair, tp1)).encode());

        Msg p2 = Msg.decode(io.read());
        if (p2.type != Proto.PAIR2 || p2.n() != 8) throw new SecurityException("PCの応答が不正です");
        byte[] tp2 = c.sha3(label("P2"), tp1, p2.head(5).encode());
        if (!Bytes.eq(p2.get(7), c.hmac(kpair, tp2))) throw new SecurityException("PCの認証に失敗");
        byte[] pcFp = c.sha3(Proto.bundle(p2.get(0), p2.get(1), p2.get(2), p2.get(3)));
        if (!Bytes.eq(Bytes.slice(pcFp, 0, 16), qr.fp16)) throw new SecurityException("PCの鍵がQRと一致しません");
        PublicKey pcDsa = c.pub(Pqc.MLDSA, p2.get(2)), pcEd = c.pub(Pqc.ED448, p2.get(3));
        c.pub(Pqc.MLKEM, p2.get(0));
        c.pub(Pqc.X448, p2.get(1));
        if (!c.verify(Pqc.MLDSA, pcDsa, tp2, p2.get(5)) || !c.verify(Pqc.ED448, pcEd, tp2, p2.get(6)))
            throw new SecurityException("PCの署名が不正です");

        if (!cb.confirm(Proto.code6(c, tp2))) throw new SecurityException("中止しました");

        byte[] tp3 = c.sha3(label("P3"), tp2);
        io.write(new Msg(Proto.PAIR3, c.sign(Pqc.MLDSA, dsa.getPrivate(), tp3), c.sign(Pqc.ED448, ed.getPrivate(), tp3),
                c.hmac(kpair, tp3)).encode());

        Msg p4 = Msg.decode(io.read());
        if (p4.type != Proto.PAIR4 || p4.n() != 1 || !Bytes.eq(p4.get(0), c.hmac(kpair, c.sha3(label("P4"), tp3))))
            throw new SecurityException("PC側で承認されませんでした");

        PairResult r = new PairResult();
        r.pcKem = p2.get(0); r.pcX = p2.get(1); r.pcDsa = p2.get(2); r.pcEd = p2.get(3); r.pcFp = pcFp;
        r.psk0 = c.hkdf(tp2, qr.psk, label("psk0"), 64);
        r.phoneFp = phoneFp(c, dsaPk, edPk);
        r.host = qr.host; r.port = qr.port;
        Bytes.wipe(kpair);
        return r;
    }

    /** セッション確立：ML-KEM-768 + X448 + ラチェットPSK の三系統で鍵合成 */
    public static Session connect(Pqc c, IO io, PhoneState st) throws Exception {
        KeyPair eph = c.genX448();
        byte[][] e = c.encaps(st.pcKem());
        byte[] ssX = c.x448(eph.getPrivate(), st.pcX());
        long n = st.n();
        byte[] psk = st.psk();

        Msg core = new Msg(Proto.H1, Bytes.slice(st.phoneFp(), 0, 16), Bytes.u64(n), eph.getPublic().getEncoded(), e[0],
                Bytes.rnd(32), Bytes.u64(Proto.now()));
        byte[] t1 = c.sha3(label("H1"), Proto.ALG, st.pcFp(), core.encode());
        io.write(core.with(c.sign(Pqc.MLDSA, st.phoneDsa(), t1), c.sign(Pqc.ED448, st.phoneEd(), t1)).encode());

        Msg h2 = Msg.decode(io.read());
        if (h2.type != Proto.H2 || h2.n() != 4) throw new SecurityException("H2");
        byte[] okm = c.hkdf(t1, Bytes.cat(e[1], ssX, psk), label("session"), 128);
        byte[] kP2C = Bytes.slice(okm, 0, 32), kC2P = Bytes.slice(okm, 32, 64), kConf = Bytes.slice(okm, 64, 128);
        byte[] t2 = c.sha3(label("H2"), t1, h2.get(0));
        if (!Bytes.eq(h2.get(3), c.hmac(kConf, t2))) throw new SecurityException("PC鍵確認失敗");
        if (!c.verify(Pqc.MLDSA, st.pcDsa(), t2, h2.get(1)) || !c.verify(Pqc.ED448, st.pcEd(), t2, h2.get(2)))
            throw new SecurityException("PC署名不正");

        st.commit(c.hkdf(t2, Bytes.cat(psk, kConf), label("ratchet"), 64), n + 1);
        Bytes.wipe(e[1], ssX, psk, okm, kConf);
        return new Session(new Channel(c, io, kC2P, kP2C, (byte) 1, (byte) 2), t2);
    }

    /**
     * 認証応答（チャレンジ・通信内容に束縛して両方式で署名）。
     * location は緊急時のみ "緯度,経度,精度m"（通常時は空）。暗号化チャネル内で送られる。
     */
    public static void respond(Pqc c, Session s, PhoneState st, byte[] reqId, byte[] challenge, byte[] material, boolean duress,
            String location) throws Exception {
        Msg core = new Msg(Proto.RESP, reqId, challenge, material, new byte[]{(byte) (duress ? 1 : 0)},
                Bytes.utf8(location == null ? "" : location));
        byte[] t = c.sha3(label("RESP"), s.t2, core.encode());
        s.ch.send(core.with(c.sign(Pqc.MLDSA, st.phoneDsa(), t), c.sign(Pqc.ED448, st.phoneEd(), t)));
    }
}
