package com.rarn.suicakey.core;

import java.security.PrivateKey;
import java.security.PublicKey;

/** スマホ側の永続状態 */
public interface PhoneState {
    byte[] pcFp() throws Exception;
    PublicKey pcKem() throws Exception;
    PublicKey pcX() throws Exception;
    PublicKey pcDsa() throws Exception;
    PublicKey pcEd() throws Exception;
    byte[] phoneFp() throws Exception;
    PrivateKey phoneDsa() throws Exception;
    PrivateKey phoneEd() throws Exception;
    byte[] psk() throws Exception;
    long n() throws Exception;
    /** ラチェット更新（同期的に永続化すること） */
    void commit(byte[] newPsk, long newN) throws Exception;
}
