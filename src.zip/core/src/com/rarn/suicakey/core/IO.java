package com.rarn.suicakey.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/** 長さ付きフレーム入出力 [len u32][payload] */
public final class IO implements Closeable {
    public static final int MAX = 64 * 1024;
    private final Socket s;
    private final DataInputStream in;
    private final DataOutputStream out;

    public IO(Socket s) throws IOException {
        this.s = s;
        this.in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
        this.out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
    }

    public synchronized void write(byte[] b) throws IOException {
        if (b.length > MAX) throw new IOException("too large");
        out.writeInt(b.length);
        out.write(b);
        out.flush();
    }

    public byte[] read() throws IOException {
        int n = in.readInt();
        if (n < 1 || n > MAX) throw new IOException("bad frame");
        byte[] b = new byte[n];
        in.readFully(b);
        return b;
    }

    public void setTimeout(int ms) throws IOException { s.setSoTimeout(ms); }

    @Override
    public void close() {
        try { s.close(); } catch (IOException ignored) { }
    }
}
