package com.rarn.suicakey.core;

import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * 暗号プリミティブの抽象層。
 * Windows: JDK 25 標準プロバイダ / Android: BouncyCastle。
 * ハッシュ系はすべて SHA3-512（HMAC-SHA3-512, HKDF-HMAC-SHA3-512）。
 */
public abstract class Pqc {
    public static final String MLKEM = "ML-KEM";
    public static final String MLDSA = "ML-DSA";
    public static final String X448 = "X448";
    public static final String ED448 = "Ed448";
    private static final String HMAC = "HmacSHA3-512";

    protected final String prov;

    protected Pqc(String provider) { this.prov = provider; }

    protected KeyPairGenerator kpg(String a) throws GeneralSecurityException {
        return prov == null ? KeyPairGenerator.getInstance(a) : KeyPairGenerator.getInstance(a, prov);
    }

    private KeyFactory kf(String a) throws GeneralSecurityException {
        return prov == null ? KeyFactory.getInstance(a) : KeyFactory.getInstance(a, prov);
    }

    private Signature sig(String a) throws GeneralSecurityException {
        return prov == null ? Signature.getInstance(a) : Signature.getInstance(a, prov);
    }

    private MessageDigest md() throws GeneralSecurityException {
        return prov == null ? MessageDigest.getInstance("SHA3-512") : MessageDigest.getInstance("SHA3-512", prov);
    }

    private Mac mac() throws GeneralSecurityException {
        return prov == null ? Mac.getInstance(HMAC) : Mac.getInstance(HMAC, prov);
    }

    // ── 鍵生成 ──
    public abstract KeyPair genMlKem768() throws GeneralSecurityException;
    public abstract KeyPair genMlDsa65() throws GeneralSecurityException;
    public KeyPair genX448() throws GeneralSecurityException { return kpg(X448).generateKeyPair(); }
    public KeyPair genEd448() throws GeneralSecurityException { return kpg(ED448).generateKeyPair(); }

    // ── 格子暗号KEM ──
    /** @return {暗号文, 共有秘密32B} */
    public abstract byte[][] encaps(PublicKey mlkemPk) throws GeneralSecurityException;
    public abstract byte[] decaps(PrivateKey mlkemSk, byte[] ct) throws GeneralSecurityException;

    // ── 鍵の復元 ──
    public PublicKey pub(String alg, byte[] spki) throws GeneralSecurityException {
        return kf(alg).generatePublic(new X509EncodedKeySpec(spki));
    }

    public PrivateKey priv(String alg, byte[] pkcs8) throws GeneralSecurityException {
        return kf(alg).generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
    }

    // ── 署名 ──
    public byte[] sign(String alg, PrivateKey k, byte[] m) throws GeneralSecurityException {
        Signature s = sig(alg);
        s.initSign(k, Bytes.RNG);
        s.update(m);
        return s.sign();
    }

    public boolean verify(String alg, PublicKey k, byte[] m, byte[] sg) {
        try {
            Signature s = sig(alg);
            s.initVerify(k);
            s.update(m);
            return s.verify(sg);
        } catch (Exception e) {
            return false;
        }
    }

    // ── X448 ──
    public byte[] x448(PrivateKey sk, PublicKey pk) throws GeneralSecurityException {
        KeyAgreement a = prov == null ? KeyAgreement.getInstance(X448) : KeyAgreement.getInstance(X448, prov);
        a.init(sk);
        a.doPhase(pk, true);
        return a.generateSecret();
    }

    // ── SHA3-512系 ──
    public byte[] sha3(byte[]... parts) throws GeneralSecurityException {
        MessageDigest d = md();
        for (byte[] p : parts) d.update(p);
        return d.digest();
    }

    public byte[] hmac(byte[] key, byte[]... parts) throws GeneralSecurityException {
        Mac m = mac();
        m.init(new SecretKeySpec(key, HMAC));
        for (byte[] p : parts) m.update(p);
        return m.doFinal();
    }

    /** PBKDF2 (RFC 8018) with HMAC-SHA3-512（総当たりを遅くするための反復） */
    public byte[] pbkdf2(byte[] pw, byte[] salt, int iter, int len) throws GeneralSecurityException {
        if (pw.length == 0) throw new IllegalArgumentException("empty password");
        Mac m = mac();
        m.init(new SecretKeySpec(pw, HMAC));
        byte[] out = new byte[len];
        int pos = 0;
        for (int blk = 1; pos < len; blk++) {
            m.update(salt);
            m.update(new byte[]{(byte) (blk >>> 24), (byte) (blk >>> 16), (byte) (blk >>> 8), (byte) blk});
            byte[] u = m.doFinal();
            byte[] t = u.clone();
            for (int i = 1; i < iter; i++) {
                u = m.doFinal(u);
                for (int k = 0; k < t.length; k++) t[k] ^= u[k];
            }
            int c = Math.min(t.length, len - pos);
            System.arraycopy(t, 0, out, pos, c);
            pos += c;
            Bytes.wipe(u, t);
        }
        return out;
    }

    /** HKDF (RFC 5869) with HMAC-SHA3-512 */
    public byte[] hkdf(byte[] salt, byte[] ikm, byte[] info, int len) throws GeneralSecurityException {
        if (len > 255 * 64) throw new IllegalArgumentException("len");
        byte[] prk = hmac(salt == null || salt.length == 0 ? new byte[64] : salt, ikm);
        byte[] out = new byte[len];
        byte[] t = new byte[0];
        int pos = 0;
        for (int i = 1; pos < len; i++) {
            t = hmac(prk, t, info, new byte[]{(byte) i});
            int c = Math.min(t.length, len - pos);
            System.arraycopy(t, 0, out, pos, c);
            pos += c;
        }
        Bytes.wipe(prk, t);
        return out;
    }

    // ── AES-256-GCM ──
    public byte[] gcm(boolean enc, byte[] key, byte[] nonce, byte[] aad, byte[] in) throws GeneralSecurityException {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(enc ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
        c.updateAAD(aad);
        return c.doFinal(in);
    }
}
