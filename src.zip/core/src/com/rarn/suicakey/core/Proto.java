package com.rarn.suicakey.core;

import java.security.GeneralSecurityException;

/** プロトコル定数と共通処理 */
public final class Proto {
    private Proto() {}

    public static final int PORT = 8765;

    /** 方式識別子（署名対象に含め、格下げ攻撃を防ぐ） */
    public static final byte[] ALG = Bytes.utf8(
            "SuicaKey/1|ML-KEM-768+X448|ML-DSA-65+Ed448|AES-256-GCM|HKDF-HMAC-SHA3-512");

    // 平文メッセージ
    public static final int PAIR1 = 0x11, PAIR2 = 0x12, PAIR3 = 0x13, PAIR4 = 0x14;
    public static final int H1 = 0x21, H2 = 0x22;
    // 暗号化チャネル内メッセージ
    public static final int REQ = 0x31, WANT = 0x32, RESP = 0x33, DONE = 0x34, PING = 0x35, PONG = 0x36;
    /** 暗号化フレームの先頭バイト */
    public static final byte ENC = (byte) 0xE0;

    public static final long TS_SKEW_SEC = 300;

    public static byte[] label(String s) { return Bytes.utf8("SK1 " + s); }

    /** 両画面で照合する6桁の確認コード */
    public static int code6(Pqc c, byte[] transcript) throws GeneralSecurityException {
        byte[] h = c.sha3(label("code"), transcript);
        long v = ((long) (h[0] & 0xff) << 32) | ((long) (h[1] & 0xff) << 24) | ((h[2] & 0xff) << 16) | ((h[3] & 0xff) << 8) | (h[4] & 0xff);
        return (int) (v % 1_000_000L);
    }

    /** 通信量から内容を推測されないよう長さを固定バケットに揃える */
    public static byte[] pad(byte[] m) {
        int total = 4 + m.length;
        int bucket = total <= 512 ? 512 : ((total + 4095) / 4096) * 4096;
        byte[] o = new byte[bucket];
        o[0] = (byte) (m.length >>> 24); o[1] = (byte) (m.length >>> 16); o[2] = (byte) (m.length >>> 8); o[3] = (byte) m.length;
        System.arraycopy(m, 0, o, 4, m.length);
        return o;
    }

    public static byte[] unpad(byte[] p) throws java.io.IOException {
        if (p.length < 4) throw new java.io.IOException("pad");
        int l = ((p[0] & 0xff) << 24) | ((p[1] & 0xff) << 16) | ((p[2] & 0xff) << 8) | (p[3] & 0xff);
        if (l < 0 || l > p.length - 4) throw new java.io.IOException("pad");
        return Bytes.slice(p, 4, 4 + l);
    }

    /** 公開鍵束の符号化（指紋計算用） */
    public static byte[] bundle(byte[]... spkis) { return new Msg(0, spkis).encode(); }

    public static long now() { return System.currentTimeMillis() / 1000; }
}
