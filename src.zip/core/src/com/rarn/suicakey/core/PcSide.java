package com.rarn.suicakey.core;

import static com.rarn.suicakey.core.Proto.label;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;

/** PC側プロトコル。検証失敗時は何も返さない（null/false → 呼び出し側は無言で切断） */
public final class PcSide {
    private PcSide() {}

    /** PCの長期鍵 */
    public static final class PcKeys {
        public PrivateKey kemSk, xSk, dsaSk, edSk;
        public byte[] kemPk, xPk, dsaPk, edPk, fp;
        /** パスワード導出に混ぜるPC固有秘密（DPAPI保護） */
        public byte[] bind;

        public static PcKeys generate(Pqc c) throws Exception {
            PcKeys k = new PcKeys();
            KeyPair a = c.genMlKem768(), b = c.genX448(), d = c.genMlDsa65(), e = c.genEd448();
            k.kemSk = a.getPrivate(); k.kemPk = a.getPublic().getEncoded();
            k.xSk = b.getPrivate(); k.xPk = b.getPublic().getEncoded();
            k.dsaSk = d.getPrivate(); k.dsaPk = d.getPublic().getEncoded();
            k.edSk = e.getPrivate(); k.edPk = e.getPublic().getEncoded();
            k.bind = Bytes.rnd(64);
            k.finish(c);
            return k;
        }

        public void finish(Pqc c) throws Exception { fp = c.sha3(Proto.bundle(kemPk, xPk, dsaPk, edPk)); }
    }

    /** 登録済みスマホ */
    public static final class PhoneRec {
        public byte[] id;          // 指紋先頭16B
        public String name;
        public byte[] dsaPk, edPk;
        public byte[] psk;         // 現在のラチェット鍵
        public long n;             // カウンタ
        public byte[] pend;        // 次段（スマホ確認待ち）
        public boolean locked;     // 複製検知でロック
        public byte[] wrap;        // M を Suica×PIN×スマホ鍵 で包んだもの（未登録なら null）
        public int fails;          // 連続失敗回数（PINの正否はPCでしか判定できない）
        public boolean pinLocked;  // 連続失敗でロック（管理者パスワードで解除）
        private PublicKey dsa, ed;

        public PublicKey dsa(Pqc c) throws Exception { if (dsa == null) dsa = c.pub(Pqc.MLDSA, dsaPk); return dsa; }
        public PublicKey ed(Pqc c) throws Exception { if (ed == null) ed = c.pub(Pqc.ED448, edPk); return ed; }
    }

    public interface PcStore {
        PcKeys pc();
        PhoneRec find(byte[] id);
        void put(PhoneRec r);
        void save();
        void log(String msg);
    }

    public static final class Session {
        public final PhoneRec phone;
        public final Channel ch;
        public final byte[] t2;
        Session(PhoneRec p, Channel ch, byte[] t2) { phone = p; this.ch = ch; this.t2 = t2; }
    }

    // ───────── ペアリング ─────────
    public static boolean pair(Pqc c, IO io, Msg p1, PairCtx ctx, PcStore st) {
        try {
            if (!ctx.active() || p1.n() != 5) return false;
            byte[] kpair = c.hkdf(Proto.ALG, ctx.psk, label("pair"), 64);
            byte[] tp1 = c.sha3(label("P1"), p1.head(4).encode());
            if (!Bytes.eq(p1.get(4), c.hmac(kpair, tp1))) { ctx.bad(); return false; }
            if (!ctx.claim()) return false;
            String name = Bytes.str(p1.get(3));
            if (name.length() > 64) name = name.substring(0, 64);
            byte[] dsaPk = p1.get(0), edPk = p1.get(1);
            PublicKey dsa = c.pub(Pqc.MLDSA, dsaPk), ed = c.pub(Pqc.ED448, edPk);

            PcKeys k = st.pc();
            Msg p2 = new Msg(Proto.PAIR2, k.kemPk, k.xPk, k.dsaPk, k.edPk, Bytes.rnd(32));
            byte[] tp2 = c.sha3(label("P2"), tp1, p2.encode());
            io.write(p2.with(c.sign(Pqc.MLDSA, k.dsaSk, tp2), c.sign(Pqc.ED448, k.edSk, tp2), c.hmac(kpair, tp2)).encode());
            ctx.code(Proto.code6(c, tp2), name);

            Msg p3 = Msg.decode(io.read());
            byte[] tp3 = c.sha3(label("P3"), tp2);
            if (p3.type != Proto.PAIR3 || p3.n() != 3 || !Bytes.eq(p3.get(2), c.hmac(kpair, tp3))
                    || !c.verify(Pqc.MLDSA, dsa, tp3, p3.get(0)) || !c.verify(Pqc.ED448, ed, tp3, p3.get(1))) {
                ctx.bad();
                return false;
            }
            ctx.verified();
            if (!ctx.awaitUser(180_000)) return false;

            PhoneRec r = new PhoneRec();
            r.dsaPk = dsaPk; r.edPk = edPk; r.name = name;
            r.id = Bytes.slice(PhoneSide.phoneFp(c, dsaPk, edPk), 0, 16);
            r.psk = c.hkdf(tp2, ctx.psk, label("psk0"), 64);
            r.n = 0;
            st.put(r);
            st.log("ペアリング: " + name);
            st.save();
            io.write(new Msg(Proto.PAIR4, c.hmac(kpair, c.sha3(label("P4"), tp3))).encode());
            ctx.done(name);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ───────── セッション確立 ─────────
    public static Session session(Pqc c, IO io, Msg h1, PcStore st) {
        try {
            if (h1.type != Proto.H1 || h1.n() != 8) return null;
            PhoneRec r = st.find(h1.get(0));
            if (r == null || r.locked) return null;
            long n = Bytes.u64(h1.get(1));
            long ts = Bytes.u64(h1.get(5));
            if (Math.abs(Proto.now() - ts) > Proto.TS_SKEW_SEC) return null;

            PcKeys k = st.pc();
            byte[] t1 = c.sha3(label("H1"), Proto.ALG, k.fp, h1.head(6).encode());
            if (!c.verify(Pqc.MLDSA, r.dsa(c), t1, h1.get(6)) || !c.verify(Pqc.ED448, r.ed(c), t1, h1.get(7))) return null;

            byte[] psk;
            synchronized (r) {
                if (n == r.n) {
                    psk = r.psk;
                } else if (r.pend != null && n == r.n + 1) {
                    r.psk = r.pend; r.n = n; r.pend = null;
                    st.save();
                    psk = r.psk;
                } else if (n < r.n) {
                    // 署名は正しいのに古いカウンタ → 端末の複製を検知
                    r.locked = true;
                    st.log("複製の疑いでロック: " + r.name + "（受信 " + n + " < 現在 " + r.n + "）");
                    st.save();
                    return null;
                } else {
                    return null;
                }
            }

            byte[] ssMl = c.decaps(k.kemSk, h1.get(3));
            byte[] ssX = c.x448(k.xSk, c.pub(Pqc.X448, h1.get(2)));
            byte[] okm = c.hkdf(t1, Bytes.cat(ssMl, ssX, psk), label("session"), 128);
            byte[] kP2C = Bytes.slice(okm, 0, 32), kC2P = Bytes.slice(okm, 32, 64), kConf = Bytes.slice(okm, 64, 128);
            byte[] nonceC = Bytes.rnd(32);
            byte[] t2 = c.sha3(label("H2"), t1, nonceC);
            synchronized (r) {
                r.pend = c.hkdf(t2, Bytes.cat(psk, kConf), label("ratchet"), 64);
                st.save();
            }
            io.write(new Msg(Proto.H2, nonceC, c.sign(Pqc.MLDSA, k.dsaSk, t2), c.sign(Pqc.ED448, k.edSk, t2),
                    c.hmac(kConf, t2)).encode());
            Bytes.wipe(ssMl, ssX, okm, kConf);
            return new Session(r, new Channel(c, io, kP2C, kC2P, (byte) 2, (byte) 1), t2);
        } catch (Exception e) {
            return null;
        }
    }

    // ───────── 認証応答の検証 ─────────
    public static final int OK = 0, DURESS = 1, BAD = 2, UNREGISTERED = 3, REGISTERED = 4;
    /** この回数連続で失敗したら端末をロック */
    public static final int MAX_REMOTE_FAILS = 10;

    public static final class Result {
        public int code = BAD;
        /** OK: 本物 / DURESS: 偽のパスワード */
        public String password;
        /** DURESS時のみ: "緯度,経度,精度m"（取得できなければ空） */
        public String location = "";
        /** この応答で連続失敗ロックに到達した */
        public boolean lockedNow;
    }

    /**
     * @param registerM 登録モード時のマスター鍵（このSuica×PINで包み直して保存）。通常は null
     */
    public static Result checkResp(Pqc c, PcStore st, Session s, Msg m, byte[] reqId, byte[] challenge, long exp,
            byte[] registerM) {
        Result res = new Result();
        try {
            if (m.type != Proto.RESP || m.n() != 7) return res;
            if (!Bytes.eq(m.get(0), reqId) || !Bytes.eq(m.get(1), challenge) || Proto.now() > exp) return res;
            if (m.get(2).length != 64 || m.get(3).length != 1 || m.get(4).length > 128) return res;
            byte[] t = c.sha3(label("RESP"), s.t2, m.head(5).encode());
            PhoneRec p = s.phone;
            if (!c.verify(Pqc.MLDSA, p.dsa(c), t, m.get(5)) || !c.verify(Pqc.ED448, p.ed(c), t, m.get(6))) return res;

            synchronized (p) { if (p.pinLocked) return res; } // ロック中は判定もしない
            byte[] material = m.get(2);
            byte[] bind = st.pc().bind;
            if (m.get(3)[0] == 1) {
                // 緊急PIN: 同じ導出式で「偽のパスワード」を作る（同じSuica＋緊急PINなら毎回同じ値）
                byte[] pw = c.hkdf(bind, material, label("password"), 24);
                res.password = Bytes.b64u(pw);
                res.location = Bytes.str(m.get(4));
                Bytes.wipe(pw, material);
                res.code = DURESS;
                return res;
            }
            if (registerM != null) {
                synchronized (p) {
                    p.wrap = Vault.wrap(c, bind, material, p.id, registerM);
                    p.fails = 0;
                    st.log("カードとPINを登録: " + p.name);
                    st.save();
                }
                res.password = Vault.password(c, registerM);
                Bytes.wipe(material);
                res.code = REGISTERED;
                return res;
            }
            byte[] wrap;
            synchronized (p) { wrap = p.wrap; }
            if (wrap == null) { res.code = UNREGISTERED; return res; }
            byte[] mk = Vault.unwrap(c, bind, material, p.id, wrap);
            Bytes.wipe(material);
            if (mk == null) { // カード/PIN違い → 無反応（回数だけ数える）
                synchronized (p) {
                    p.fails++;
                    if (p.fails >= MAX_REMOTE_FAILS && !p.pinLocked) {
                        p.pinLocked = true;
                        res.lockedNow = true;
                        st.log("連続" + p.fails + "回失敗のためロック: " + p.name);
                    }
                    st.save();
                }
                return res;
            }
            synchronized (p) { if (p.fails != 0) { p.fails = 0; st.save(); } }
            res.password = Vault.password(c, mk);
            Bytes.wipe(mk);
            res.code = OK;
        } catch (Exception e) {
            res.code = BAD;
        }
        return res;
    }
}
