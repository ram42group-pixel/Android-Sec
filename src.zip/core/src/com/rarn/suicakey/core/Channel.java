package com.rarn.suicakey.core;

/** AES-256-GCM 暗号化チャネル。nonce = 方向(4B) || 連番(8B)。長さは固定バケットに揃える。 */
public final class Channel {
    private static final byte[] AAD = Proto.label("frame");
    private final Pqc c;
    private final IO io;
    private final byte[] kSend, kRecv;
    private final byte dSend, dRecv;
    private long sSeq, rSeq;

    Channel(Pqc c, IO io, byte[] kSend, byte[] kRecv, byte dSend, byte dRecv) {
        this.c = c; this.io = io; this.kSend = kSend; this.kRecv = kRecv; this.dSend = dSend; this.dRecv = dRecv;
    }

    private static byte[] nonce(byte d, long seq) {
        return Bytes.cat(new byte[]{d, 0, 0, 0}, Bytes.u64(seq));
    }

    public void send(Msg m) throws Exception {
        synchronized (this) {
            byte[] ct = c.gcm(true, kSend, nonce(dSend, sSeq++), Bytes.cat(AAD, new byte[]{dSend}), Proto.pad(m.encode()));
            io.write(Bytes.cat(new byte[]{Proto.ENC}, ct));
        }
    }

    public Msg recv() throws Exception {
        byte[] f = io.read();
        if (f[0] != Proto.ENC) throw new java.io.IOException("plain frame");
        byte[] pt = c.gcm(false, kRecv, nonce(dRecv, rSeq++), Bytes.cat(AAD, new byte[]{dRecv}), Bytes.slice(f, 1, f.length));
        return Msg.decode(Proto.unpad(pt));
    }

    public void close() { io.close(); }
}
