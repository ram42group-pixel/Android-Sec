package com.rarn.suicakey.test;

import com.rarn.suicakey.core.*;
import com.rarn.suicakey.core.IO; // JDK 25 の java.lang.IO と区別するため明示
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * PC(JDK25) ↔ スマホ(JDK or BouncyCastle) の相互運用・攻撃耐性テスト。
 * 引数: jdk | bc
 */
public final class InteropTest {
    static Pqc pc, ph;
    static final BlockingQueue<String> ev = new LinkedBlockingQueue<>();
    static PairCtx pairing;
    static MemPc store;
    static int fails;
    static volatile byte[] registerM;

    static final class MemPc implements PcSide.PcStore {
        final PcSide.PcKeys k; final Map<String, PcSide.PhoneRec> m = new HashMap<>(); final List<String> logs = new ArrayList<>();
        MemPc(PcSide.PcKeys k) { this.k = k; }
        public PcSide.PcKeys pc() { return k; }
        public PcSide.PhoneRec find(byte[] id) { return m.get(Bytes.hex(id)); }
        public void put(PcSide.PhoneRec r) { m.put(Bytes.hex(r.id), r); }
        public void save() { }
        public void log(String s) { logs.add(s); }
    }

    static final class MemPhone implements PhoneState {
        PhoneSide.PairResult r; KeyPair dsa, ed; byte[] psk; long n;
        public byte[] pcFp() { return r.pcFp; }
        public PublicKey pcKem() throws Exception { return ph.pub(Pqc.MLKEM, r.pcKem); }
        public PublicKey pcX() throws Exception { return ph.pub(Pqc.X448, r.pcX); }
        public PublicKey pcDsa() throws Exception { return ph.pub(Pqc.MLDSA, r.pcDsa); }
        public PublicKey pcEd() throws Exception { return ph.pub(Pqc.ED448, r.pcEd); }
        public byte[] phoneFp() { return r.phoneFp; }
        public PrivateKey phoneDsa() { return dsa.getPrivate(); }
        public PrivateKey phoneEd() { return ed.getPrivate(); }
        public byte[] psk() { return psk.clone(); }
        public long n() { return n; }
        public void commit(byte[] p, long nn) { psk = p; n = nn; }
        MemPhone copy() { MemPhone c = new MemPhone(); c.r = r; c.dsa = dsa; c.ed = ed; c.psk = psk.clone(); c.n = n; return c; }
    }

    static void check(boolean ok, String what) {
        System.out.println((ok ? "  OK   " : "  FAIL ") + what);
        if (!ok) fails++;
    }

    /** PC側：1接続につき1依頼で処理（Windows版Serverと同じ判定ロジックを使用） */
    static void serve(Socket s) {
        try (IO io = new IO(s)) {
            s.setSoTimeout(10_000);
            Msg m = Msg.decode(io.read());
            if (m.type == Proto.PAIR1) {
                PairCtx p = pairing;
                ev.put(p != null && PcSide.pair(pc, io, m, p, store) ? "PAIRED" : "PAIR_SILENT");
                return;
            }
            PcSide.Session ses = PcSide.session(pc, io, m, store);
            if (ses == null) { ev.put("SILENT"); return; }
            byte[] id = Bytes.rnd(16), ch = Bytes.rnd(32);
            long exp = Proto.now() + 60;
            ses.ch.send(new Msg(Proto.REQ, id, ch, Bytes.utf8("テスト依頼"), Bytes.u64(exp)));
            Msg r = ses.ch.recv();
            PcSide.Result res = PcSide.checkResp(pc, store, ses, r, id, ch, exp, registerM);
            registerM = null;
            ev.put(res.code + ":" + res.password + (res.code == PcSide.DURESS ? "@" + res.location : ""));
            if (res.code == PcSide.OK || res.code == PcSide.DURESS || res.code == PcSide.REGISTERED) ses.ch.send(new Msg(Proto.DONE, id));
        } catch (Exception e) {
            ev.offer("EXC:" + e);
        }
    }

    /** スマホ側：接続→依頼受信→応答→DONE待ち */
    static String phoneAuth(int port, MemPhone st, byte[] material, boolean duress) throws Exception {
        try (Socket s = new Socket(InetAddress.getLoopbackAddress(), port); IO io = new IO(s)) {
            s.setSoTimeout(5_000);
            PhoneSide.Session ses = PhoneSide.connect(ph, io, st);
            Msg req = ses.ch.recv();
            if (req.type != Proto.REQ) return "NOREQ";
            PhoneSide.respond(ph, ses, st, req.get(0), req.get(1), material, duress, duress ? "35.6812,139.7671,12" : "");
            try {
                Msg d = ses.ch.recv();
                return d.type == Proto.DONE ? "DONE" : "OTHER";
            } catch (Exception e) {
                return "NO_RESPONSE";
            }
        } catch (Exception e) {
            return "CONNECT_FAIL";
        }
    }

    public static void main(String[] a) throws Exception {
        Class<?> pcCls = Class.forName("com.rarn.suicakey.win.JdkPqc");
        pc = (Pqc) pcCls.getDeclaredConstructor().newInstance();
        if (a.length > 0 && a[0].equals("bc")) {
            java.security.Security.addProvider((java.security.Provider)
                    Class.forName("org.bouncycastle.jce.provider.BouncyCastleProvider").getDeclaredConstructor().newInstance());
            ph = (Pqc) Class.forName("com.rarn.suicakey.bc.BcPqc").getDeclaredConstructor().newInstance();
        } else {
            ph = (Pqc) pcCls.getDeclaredConstructor().newInstance();
        }
        System.out.println("PC=" + pc.getClass().getSimpleName() + "  Phone=" + ph.getClass().getSimpleName());

        store = new MemPc(PcSide.PcKeys.generate(pc));
        ServerSocket ss = new ServerSocket(0, 8, InetAddress.getLoopbackAddress());
        int port = ss.getLocalPort();
        Thread t = new Thread(() -> {
            while (true) {
                try { Socket s = ss.accept(); new Thread(() -> serve(s)).start(); } catch (Exception e) { return; }
            }
        });
        t.setDaemon(true);
        t.start();

        // 1. ペアリング（誤った光学鍵 → 無反応）
        byte[] psk = Bytes.rnd(32);
        int[] pcCode = {-1};
        pairing = new PairCtx(psk.clone(), 60_000, new PairCtx.Listener() {
            public void code(int c, String n) { pcCode[0] = c; }
            public void verified() { pairing.userConfirm(true); }
            public void done(String n) { }
            public void ended() { }
        });
        String fp16 = Bytes.b64u(Bytes.slice(store.k.fp, 0, 16));
        KeyPair dsa = ph.genMlDsa65(), ed = ph.genEd448();
        try (Socket s = new Socket(InetAddress.getLoopbackAddress(), port); IO io = new IO(s)) {
            s.setSoTimeout(3000);
            PhoneSide.pair(ph, io, PhoneSide.parseQr("SK1:x:1:" + Bytes.b64u(Bytes.rnd(32)) + ":" + fp16), dsa, ed, "偽端末", c -> true);
            check(false, "誤った光学鍵でペアリング拒否");
        } catch (Exception e) {
            check(true, "誤った光学鍵 → PCは無反応（" + ev.poll(3, TimeUnit.SECONDS) + "）");
        }

        MemPhone st = new MemPhone();
        st.dsa = dsa; st.ed = ed;
        int[] phCode = {-2};
        try (Socket s = new Socket(InetAddress.getLoopbackAddress(), port); IO io = new IO(s)) {
            s.setSoTimeout(10_000);
            st.r = PhoneSide.pair(ph, io, PhoneSide.parseQr("SK1:127.0.0.1:" + port + ":" + Bytes.b64u(psk) + ":" + fp16),
                    dsa, ed, "テスト端末", c -> { phCode[0] = c; return true; });
            st.psk = st.r.psk0; st.n = 0;
        }
        check("PAIRED".equals(ev.poll(5, TimeUnit.SECONDS)), "ペアリング成功");
        check(phCode[0] == pcCode[0] && phCode[0] >= 0, "確認コード一致 " + String.format("%06d", phCode[0]));
        check(Bytes.eq(store.m.values().iterator().next().psk, st.psk), "初期共有鍵一致");

        // 2. 未登録 → 無反応、キーファイル＋管理者PWで M を作り登録
        byte[] mat = Bytes.rnd(64);
        String r0 = phoneAuth(port, st, mat.clone(), false);
        String e0 = ev.poll(5, TimeUnit.SECONDS);
        check("NO_RESPONSE".equals(r0) && "3:null".equals(e0), "未登録 → 無反応");
        byte[] keyfile = Bytes.rnd(4096);
        long t0 = System.currentTimeMillis();
        byte[] M = Vault.master(pc, Vault.keyfileHash(pc, keyfile), "correct horse battery");
        System.out.println("  (PBKDF2 60万回: " + (System.currentTimeMillis() - t0) + "ms)");
        registerM = M.clone();
        String rr = phoneAuth(port, st, mat.clone(), false);
        String er = ev.poll(5, TimeUnit.SECONDS);
        check("DONE".equals(rr) && er != null && er.startsWith("4:"), "登録 " + er);
        String r1 = phoneAuth(port, st, mat.clone(), false);
        String e1 = ev.poll(5, TimeUnit.SECONDS);
        check("DONE".equals(r1) && e1 != null && e1.equals("0:" + er.substring(2)), "認証1 包みを開いて同じパスワード " + e1);
        check(e1.substring(2).equals(Vault.password(pc, Vault.master(pc, Vault.keyfileHash(pc, keyfile), "correct horse battery"))),
                "回復：キーファイル＋管理者PWだけで同じパスワードを再計算");
        check(!Bytes.eq(Vault.check(pc, M), Vault.check(pc, Vault.master(pc, Vault.keyfileHash(pc, keyfile), "wrong password!!"))),
                "管理者PWが違えば別の鍵");
        byte[] kf2 = keyfile.clone(); kf2[100] ^= 1;
        check(!Bytes.eq(Vault.check(pc, M), Vault.check(pc, Vault.master(pc, Vault.keyfileHash(pc, kf2), "correct horse battery"))),
                "キーファイルが1ビット違えば別の鍵");
        MemPhone snapshot = st.copy();

        String r2 = phoneAuth(port, st, mat.clone(), false);
        String e2 = ev.poll(5, TimeUnit.SECONDS);
        check("DONE".equals(r2) && e1.equals(e2), "認証2 同じパスワード（ラチェット後も再現）");
        check(st.n == 4, "ラチェットカウンタ n=" + st.n + "（接続ごとに更新）");

        // 3. 違うカード/PIN → 無反応
        String r3 = phoneAuth(port, st, Bytes.rnd(64), false);
        String e3 = ev.poll(5, TimeUnit.SECONDS);
        check("NO_RESPONSE".equals(r3) && e3 != null && e3.startsWith("2:"), "誤った素材 → 無反応 (" + r3 + ")");

        // 4. 緊急PIN → 偽のパスワード（毎回同じ・本物と別）＋位置情報
        byte[] dmat = Bytes.rnd(64);
        String r4 = phoneAuth(port, st, dmat.clone(), true);
        String e4 = ev.poll(5, TimeUnit.SECONDS);
        String r4b = phoneAuth(port, st, dmat.clone(), true);
        String e4b = ev.poll(5, TimeUnit.SECONDS);
        check("DONE".equals(r4) && e4 != null && e4.startsWith("1:") && e4.endsWith("@35.6812,139.7671,12"), "緊急PIN → 偽パスワード＋位置 " + e4);
        check("DONE".equals(r4b) && e4.equals(e4b), "偽パスワードは毎回同じ");
        check(!e4.substring(2, 34).equals(e1.substring(2)), "偽パスワードは本物と異なる");

        // 4b. スマホ紛失 → 新スマホ（別の素材）を M で再登録 → 同じパスワード
        PcSide.PhoneRec cur = store.m.values().iterator().next();
        byte[] newMat = Bytes.rnd(64);
        registerM = Vault.master(pc, Vault.keyfileHash(pc, keyfile), "correct horse battery");
        phoneAuth(port, st, newMat.clone(), false);
        String eReg = ev.poll(5, TimeUnit.SECONDS);
        phoneAuth(port, st, newMat.clone(), false);
        String eNew = ev.poll(5, TimeUnit.SECONDS);
        check(eReg != null && eReg.startsWith("4:") && ("0:" + e1.substring(2)).equals(eNew), "再登録後も同じパスワード");
        phoneAuth(port, st, mat.clone(), false);
        check(("2:null").equals(ev.poll(5, TimeUnit.SECONDS)), "古いカード/PINは無効化 → 無反応");

        // 4c. スマホ内でPINを確かめる手段はない → 総当たりは必ずPC経由 → 10回連続失敗でロック
        for (int i = 0; i < PcSide.MAX_REMOTE_FAILS; i++) { phoneAuth(port, st, Bytes.rnd(64), false); ev.poll(5, TimeUnit.SECONDS); }
        check(cur.pinLocked, "PIN総当たり：連続" + PcSide.MAX_REMOTE_FAILS + "回失敗でロック");
        String rl = phoneAuth(port, st, newMat.clone(), false);
        check("NO_RESPONSE".equals(rl) && "2:null".equals(ev.poll(5, TimeUnit.SECONDS)), "ロック中は正しいPINでも無反応");
        cur.pinLocked = false; cur.fails = 0; // 管理者による解除
        phoneAuth(port, st, newMat.clone(), false);
        check(("0:" + e1.substring(2)).equals(ev.poll(5, TimeUnit.SECONDS)), "管理者が解除すると復帰");

        // 5. 複製検知（古い状態の複製で接続）
        String r5 = phoneAuth(port, snapshot, mat.clone(), false);
        String e5 = ev.poll(5, TimeUnit.SECONDS);
        PcSide.PhoneRec rec = store.m.values().iterator().next();
        check("CONNECT_FAIL".equals(r5) && "SILENT".equals(e5) && rec.locked, "複製端末を検知してロック");
        String r6 = phoneAuth(port, st, mat.clone(), false);
        check("CONNECT_FAIL".equals(r6), "ロック後は正規端末も停止（再ペアリングが必要）");

        // 6. 改ざん: 未登録の鍵で署名した接続 → 無反応
        rec.locked = false;
        MemPhone evil = st.copy();
        evil.dsa = ph.genMlDsa65();
        String r7 = phoneAuth(port, evil, mat.clone(), false);
        check("CONNECT_FAIL".equals(r7) && "SILENT".equals(ev.poll(5, TimeUnit.SECONDS)), "偽の署名鍵 → 無反応");

        System.out.println("logs: " + store.logs);
        System.out.println(fails == 0 ? "ALL OK" : ("FAILED: " + fails));
        System.exit(fails == 0 ? 0 : 1);
    }
}
