#!/usr/bin/env bash
# Windows版: JDK25でビルド → jpackage（Java同梱、インストール不要）
set -euo pipefail
mkdir -p lib out app
curl -sSfL -o lib/zxing.jar https://repo1.maven.org/maven2/com/google/zxing/core/3.5.3/core-3.5.3.jar
javac -encoding UTF-8 --release 25 -cp lib/zxing.jar -d out $(find core/src windows/src -name '*.java')
jar --create --file app/suicakey.jar --main-class com.rarn.suicakey.win.Main -C out .
cp lib/zxing.jar app/
jpackage --type app-image --name SuicaKey --input app --main-jar suicakey.jar \
  --main-class com.rarn.suicakey.win.Main --app-version 2.0.0 --vendor rarn \
  --java-options "--enable-native-access=ALL-UNNAMED" --dest dist
cd dist && 7z a -tzip ../SuicaKey-windows.zip SuicaKey >/dev/null
