#!/usr/bin/env bash
# Android: リリース版（デバッグ不可）をビルドして署名
set -euo pipefail
cd android
if [ -n "${ANDROID_KEYSTORE_B64:-}" ]; then
  echo "$ANDROID_KEYSTORE_B64" | base64 -d > release.jks
  export SK_KS_PASS="${ANDROID_KEYSTORE_PASS:?ANDROID_KEYSTORE_PASS が未設定}"
else
  echo "::warning::署名鍵のSecretが未設定のため一時鍵で署名します（アプリ更新時はアンインストールが必要）"
  export SK_KS_PASS="$(head -c 32 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24)"
  keytool -genkeypair -keystore release.jks -storetype PKCS12 -storepass "$SK_KS_PASS" -keypass "$SK_KS_PASS" \
    -alias sk -keyalg RSA -keysize 4096 -validity 10000 -dname "CN=SuicaKey" >/dev/null 2>&1
fi
export SK_KS_PATH="$PWD/release.jks" SK_KEY_ALIAS="${ANDROID_KEY_ALIAS:-sk}"
gradle :app:assembleRelease --no-daemon
cp app/build/outputs/apk/release/app-release.apk ../SuicaKey-android.apk
rm -f release.jks
