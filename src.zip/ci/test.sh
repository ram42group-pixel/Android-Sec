#!/usr/bin/env bash
# 相互運用テスト: PC(JDK25標準) ↔ スマホ(JDK25 / BouncyCastle)
set -euo pipefail
mkdir -p lib out
curl -sSfL -o lib/bcprov.jar https://repo1.maven.org/maven2/org/bouncycastle/bcprov-jdk18on/1.81/bcprov-jdk18on-1.81.jar
javac -encoding UTF-8 -d out -cp lib/bcprov.jar \
  $(find core/src core-bc/src core/test -name '*.java') windows/src/com/rarn/suicakey/win/JdkPqc.java
java -Dstdout.encoding=UTF-8 -cp out:lib/bcprov.jar com.rarn.suicakey.test.InteropTest jdk
java -Dstdout.encoding=UTF-8 -cp out:lib/bcprov.jar com.rarn.suicakey.test.InteropTest bc
